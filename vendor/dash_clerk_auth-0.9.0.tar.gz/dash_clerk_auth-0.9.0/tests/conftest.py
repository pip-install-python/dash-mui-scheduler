"""Shared pytest fixtures for dash-clerk-auth tests.

These tests don't talk to the real Clerk API. The async client is patched
to return canned ``RequestState``-like objects so we can exercise the
full ASGI middleware → ContextVar → decorator flow without network I/O.
"""

from __future__ import annotations

import asyncio
import os
from types import SimpleNamespace
from typing import Any, Optional
from unittest.mock import patch

import pytest

# Set a test secret so get_async_client doesn't raise on import-time configs.
os.environ.setdefault("CLERK_SECRET_KEY", "sk_test_dummy_for_tests")


def _request_state(*, signed_in: bool, payload: Optional[dict] = None, reason: str = ""):
    """Build a mock object that quacks like ``clerk_backend_api.RequestState``."""
    return SimpleNamespace(
        is_signed_in=signed_in,
        payload=payload or {},
        reason=reason,
    )


@pytest.fixture(autouse=True)
def _reset_clerk_caches():
    """Drop the JWT/user/list caches between tests so they don't leak."""
    from dash_clerk_auth import _clerk_client

    _clerk_client._reset_caches()
    yield
    _clerk_client._reset_caches()


@pytest.fixture
def patch_clerk_async(monkeypatch):
    """Patch the singleton async Clerk client with a programmable mock.

    Yields a callable ``set_response(payload=None, signed_in=True)`` so each
    test can stage a different verdict.
    """
    state_holder = {"signed_in": True, "payload": {"sub": "user_test", "email": "t@x.com"}}

    class _MockClient:
        async def authenticate_request_async(self, request, options):
            return _request_state(
                signed_in=state_holder["signed_in"], payload=state_holder["payload"]
            )

        class users:  # noqa: D106 — match SDK shape
            @staticmethod
            async def list_async(request=None):
                return state_holder.get("users", [])

            @staticmethod
            async def get_async(user_id):
                return state_holder.get("user_by_id", {"id": user_id})

    from dash_clerk_auth import _clerk_client

    monkeypatch.setattr(_clerk_client, "get_async_client", lambda: _MockClient())

    def set_response(payload=None, signed_in=True, users=None, user_by_id=None):
        if payload is not None:
            state_holder["payload"] = payload
        state_holder["signed_in"] = signed_in
        if users is not None:
            state_holder["users"] = users
        if user_by_id is not None:
            state_holder["user_by_id"] = user_by_id

    yield set_response


@pytest.fixture
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()
