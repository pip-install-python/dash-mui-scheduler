"""Async Clerk client wrappers — TTL cache, single-flight, force-refresh."""

from __future__ import annotations

import asyncio
import time

import pytest

from dash_clerk_auth import averify_request, alist_users_cached, aget_user_by_id
from dash_clerk_auth._clerk_client import _TTLCache


pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# _TTLCache primitive
# ---------------------------------------------------------------------------
async def test_ttl_cache_hit():
    cache = _TTLCache(default_ttl=60.0)
    calls = {"n": 0}

    async def loader():
        calls["n"] += 1
        return "value"

    v1 = await cache.get_or_load("k", loader)
    v2 = await cache.get_or_load("k", loader)
    assert v1 == "value"
    assert v2 == "value"
    assert calls["n"] == 1


async def test_ttl_cache_force_bypasses():
    cache = _TTLCache(default_ttl=60.0)
    calls = {"n": 0}

    async def loader():
        calls["n"] += 1
        return calls["n"]

    await cache.get_or_load("k", loader)
    v = await cache.get_or_load("k", loader, force=True)
    assert v == 2
    assert calls["n"] == 2


async def test_ttl_cache_expiry():
    cache = _TTLCache(default_ttl=0.05)
    calls = {"n": 0}

    async def loader():
        calls["n"] += 1
        return calls["n"]

    v1 = await cache.get_or_load("k", loader)
    await asyncio.sleep(0.08)
    v2 = await cache.get_or_load("k", loader)
    assert v1 == 1 and v2 == 2


async def test_ttl_cache_single_flight_under_concurrency():
    cache = _TTLCache(default_ttl=60.0)
    calls = {"n": 0}

    async def slow_loader():
        calls["n"] += 1
        await asyncio.sleep(0.02)
        return "v"

    results = await asyncio.gather(
        *[cache.get_or_load("k", slow_loader) for _ in range(20)]
    )
    assert all(r == "v" for r in results)
    assert calls["n"] == 1  # 20 callers, 1 actual load


# ---------------------------------------------------------------------------
# averify_request — uses the patch_clerk_async fixture
# ---------------------------------------------------------------------------
async def test_averify_request_signed_in(patch_clerk_async):
    patch_clerk_async(payload={"sub": "u_a", "email": "a@x.com"}, signed_in=True)
    user = await averify_request(
        method="GET",
        url="http://test/",
        headers={"authorization": "Bearer t"},
    )
    assert user is not None
    assert user.user_id == "u_a"


async def test_averify_request_unsigned_returns_none(patch_clerk_async):
    patch_clerk_async(signed_in=False)
    user = await averify_request(headers={"authorization": "Bearer t"})
    assert user is None


async def test_averify_request_caches(patch_clerk_async):
    """Same headers/cookies twice ⇒ Clerk only called once."""
    counter = {"n": 0}

    class MockClient:
        async def authenticate_request_async(self, request, options):
            from types import SimpleNamespace

            counter["n"] += 1
            return SimpleNamespace(
                is_signed_in=True,
                payload={"sub": "u", "exp": time.time() + 600},
                reason="",
            )

    from dash_clerk_auth import _clerk_client

    _clerk_client.get_async_client = lambda: MockClient()  # type: ignore

    headers = {"authorization": "Bearer same-token"}
    u1 = await averify_request(headers=headers)
    u2 = await averify_request(headers=headers)
    assert u1 is not None and u2 is not None
    assert counter["n"] == 1


# ---------------------------------------------------------------------------
# alist_users_cached + aget_user_by_id
# ---------------------------------------------------------------------------
async def test_alist_users_cached_hits_cache(patch_clerk_async):
    counter = {"n": 0}

    class MockClient:
        class users:
            @staticmethod
            async def list_async(request=None):
                counter["n"] += 1
                return [{"id": "u_1"}]

    from dash_clerk_auth import _clerk_client

    _clerk_client.get_async_client = lambda: MockClient()  # type: ignore

    a = await alist_users_cached()
    b = await alist_users_cached()
    assert a == b == [{"id": "u_1"}]
    assert counter["n"] == 1

    # force=True bypasses
    c = await alist_users_cached(force=True)
    assert c == [{"id": "u_1"}]
    assert counter["n"] == 2


async def test_aget_user_by_id(patch_clerk_async):
    patch_clerk_async(user_by_id={"id": "u_42", "first_name": "X"})
    out = await aget_user_by_id("u_42")
    assert out["id"] == "u_42"


# ---------------------------------------------------------------------------
# Self-heal on a closed event loop (the Dash 4.2 cross-loop hazard safety net).
# ---------------------------------------------------------------------------
class _FakeGetClient:
    """Stands in for the lru_cached get_async_client (has .cache_clear)."""

    def __init__(self, behaviour):
        self.auth_calls = 0
        self.cleared = 0
        self._behaviour = behaviour  # callable(call_index) -> request_state OR raises

    def cache_clear(self):
        self.cleared += 1

    def __call__(self):
        outer = self

        class _Client:
            async def authenticate_request_async(self, request, options):
                outer.auth_calls += 1
                return outer._behaviour(outer.auth_calls)

        return _Client()


async def test_averify_rebuilds_client_on_closed_loop(monkeypatch):
    """First call raises 'Event loop is closed' → rebuild + retry once → ok."""
    from types import SimpleNamespace
    from dash_clerk_auth import _clerk_client

    def behaviour(n):
        if n == 1:
            raise RuntimeError("Event loop is closed")
        return SimpleNamespace(
            is_signed_in=True,
            payload={"sub": "u_heal", "exp": time.time() + 600},
            reason="",
        )

    fake = _FakeGetClient(behaviour)
    monkeypatch.setattr(_clerk_client, "get_async_client", fake)

    user = await averify_request(headers={"authorization": "Bearer t"})
    assert user is not None and user.user_id == "u_heal"
    assert fake.cleared == 1          # client was rebuilt exactly once
    assert fake.auth_calls == 2       # original + one retry


async def test_averify_does_not_retry_on_other_errors(monkeypatch):
    """A non-loop error must NOT rebuild/retry — returns None after one try."""
    from dash_clerk_auth import _clerk_client

    def behaviour(n):
        raise ValueError("some other failure")

    fake = _FakeGetClient(behaviour)
    monkeypatch.setattr(_clerk_client, "get_async_client", fake)

    user = await averify_request(headers={"authorization": "Bearer t"})
    assert user is None
    assert fake.cleared == 0
    assert fake.auth_calls == 1


async def test_averify_self_heals_on_bound_to_different_loop(monkeypatch):
    """The 'is bound to a different event loop' variant must also self-heal.

    asyncio Lock/Event/Semaphore (incl. the anyio primitives httpcore wraps in
    httpx's pool) raise this distinct phrasing on cross-loop reuse.
    """
    from types import SimpleNamespace
    from dash_clerk_auth import _clerk_client

    def behaviour(n):
        if n == 1:
            raise RuntimeError(
                "<asyncio.locks.Lock object at 0x1> is bound to a different event loop"
            )
        return SimpleNamespace(
            is_signed_in=True,
            payload={"sub": "u_heal2", "exp": time.time() + 600},
            reason="",
        )

    fake = _FakeGetClient(behaviour)
    monkeypatch.setattr(_clerk_client, "get_async_client", fake)

    user = await averify_request(headers={"authorization": "Bearer t"})
    assert user is not None and user.user_id == "u_heal2"
    assert fake.cleared == 1
    assert fake.auth_calls == 2


# ---------------------------------------------------------------------------
# _TTLCache degrades gracefully when its asyncio Lock/Future is reused across
# loops (Dash 4.2 per-callback asyncio.run) instead of crashing the caller.
# ---------------------------------------------------------------------------
async def test_ttl_cache_degrades_on_cross_loop_error(monkeypatch):
    cache = _TTLCache(default_ttl=60.0)
    calls = {"n": 0}

    async def loader():
        calls["n"] += 1
        return "fallback-value"

    async def cross_loop(*a, **k):
        raise RuntimeError("<Future pending> attached to a different loop")

    monkeypatch.setattr(cache, "_coordinated_load", cross_loop)
    v = await cache.get_or_load("k", loader)
    assert v == "fallback-value"   # ran the loader directly, no crash
    assert calls["n"] == 1


async def test_ttl_cache_reraises_unrelated_runtime_error(monkeypatch):
    cache = _TTLCache(default_ttl=60.0)

    async def loader():
        return "x"

    async def boom(*a, **k):
        raise RuntimeError("totally unrelated")

    monkeypatch.setattr(cache, "_coordinated_load", boom)
    with pytest.raises(RuntimeError, match="totally unrelated"):
        await cache.get_or_load("k", loader)
