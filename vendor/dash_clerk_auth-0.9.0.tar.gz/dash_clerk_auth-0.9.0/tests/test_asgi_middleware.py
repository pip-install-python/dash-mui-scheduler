"""ClerkASGIMiddleware — verify-once + ContextVar binding."""

from __future__ import annotations

import asyncio

import pytest
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from dash_clerk_auth import current_user
from dash_clerk_auth._asgi import ClerkASGIMiddleware


def _build_app(monkeypatch_or_fixture, **mw_kwargs):
    """Build a tiny Starlette app whose handler reports the bound user."""

    async def whoami(request):
        u = current_user()
        return JSONResponse(
            {
                "user_id": getattr(u, "user_id", None),
                "scope_state_user": getattr(
                    request.scope.get("state", {}).get("clerk_user"), "user_id", None
                )
                if request.scope.get("state") else None,
            }
        )

    async def static(request):
        u = current_user()
        return JSONResponse({"user_id": getattr(u, "user_id", None)})

    app = Starlette(
        routes=[
            Route("/whoami", whoami),
            Route("/_dash-component-suites/x.js", static),
        ]
    )
    app.add_middleware(ClerkASGIMiddleware, **mw_kwargs)
    return app


def test_anonymous_request_no_clerk_call(patch_clerk_async):
    """No bearer + no __session cookie ⇒ middleware skips Clerk entirely."""
    calls = {"n": 0}

    class _ShouldNotBeCalled:
        async def authenticate_request_async(self, *a, **kw):
            calls["n"] += 1
            raise AssertionError("Clerk should not be called for anonymous requests")

    from dash_clerk_auth import _clerk_client

    _clerk_client.get_async_client = lambda: _ShouldNotBeCalled()  # type: ignore

    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        resp = client.get("/whoami")
    assert resp.status_code == 200
    assert resp.json() == {"user_id": None, "scope_state_user": None}
    assert calls["n"] == 0


def test_static_path_skipped(patch_clerk_async):
    """/_dash-component-suites/* must skip verification."""
    patch_clerk_async(payload={"sub": "u_x"}, signed_in=True)
    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        # Even with cookie set, the static path is in the skip list so no user
        # is bound — the middleware doesn't even call Clerk.
        resp = client.get(
            "/_dash-component-suites/x.js",
            cookies={"__session": "fake-token"},
        )
    assert resp.status_code == 200
    assert resp.json() == {"user_id": None}


def test_signed_in_cookie_binds_user(patch_clerk_async):
    patch_clerk_async(payload={"sub": "u_42", "email": "a@b.com"}, signed_in=True)
    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        resp = client.get("/whoami", cookies={"__session": "fake-token"})
    body = resp.json()
    assert body["user_id"] == "u_42"
    assert body["scope_state_user"] == "u_42"


def test_bearer_token_binds_user(patch_clerk_async):
    patch_clerk_async(payload={"sub": "u_bear"}, signed_in=True)
    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        resp = client.get(
            "/whoami",
            headers={"Authorization": "Bearer eyJxxx.payload.sig"},
        )
    assert resp.json()["user_id"] == "u_bear"


def test_unverified_leaves_contextvar_empty(patch_clerk_async):
    patch_clerk_async(payload={}, signed_in=False)
    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        resp = client.get("/whoami", cookies={"__session": "bad"})
    assert resp.json() == {"user_id": None, "scope_state_user": None}


def test_contextvar_does_not_leak_between_requests(patch_clerk_async):
    """Sequential requests with different sessions must not share user state."""
    app = _build_app(patch_clerk_async)
    with TestClient(app) as client:
        patch_clerk_async(payload={"sub": "user_a"}, signed_in=True)
        a = client.get("/whoami", cookies={"__session": "tok-a"}).json()

        patch_clerk_async(signed_in=False)
        b = client.get("/whoami").json()  # no cookie ⇒ no Clerk call ⇒ None

        patch_clerk_async(payload={"sub": "user_c"}, signed_in=True)
        c = client.get("/whoami", cookies={"__session": "tok-c"}).json()

    assert a["user_id"] == "user_a"
    assert b["user_id"] is None
    assert c["user_id"] == "user_c"


def test_billing_enabled_populates_plan_features(patch_clerk_async):
    patch_clerk_async(
        payload={"sub": "u", "plan": "pro", "features": ["x", "y"]}, signed_in=True
    )
    app = _build_app(patch_clerk_async, billing_enabled=True)

    async def report(request):
        u = current_user()
        return JSONResponse({"plan": u.plan, "features": list(u.features)})

    # Replace the route to read plan/features.
    app.routes.insert(0, Route("/billing", report))
    with TestClient(app) as client:
        resp = client.get("/billing", cookies={"__session": "tok"})
    assert resp.json() == {"plan": "pro", "features": ["x", "y"]}
