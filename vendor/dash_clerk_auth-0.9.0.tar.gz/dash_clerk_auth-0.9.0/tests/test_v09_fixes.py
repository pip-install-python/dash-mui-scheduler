"""v0.9.0 — the 2plot.ai upstream report fixes.

Covers:

1. Email enrichment: Clerk session JWTs carry NO email claim by default —
   the realistic fixture here is the email-less payload shape
   ``{"sub", "sid", "v": 2}``. An email-filled stub masks the whole bug
   class (it did, pre-0.9).
2. Flask slow path: ``before_request`` verifies against Clerk when only a
   ``__session`` cookie is present and mints ``__dca_identity`` on the
   response — no client cooperation needed. Cookies go through
   ``client.set_cookie()`` (werkzeug's test client drops raw Cookie headers).
3. Idle-state quieting: ``__client_uat``/``__refresh_*`` without a session
   token skips the Clerk roundtrip entirely (HTTP, WS and flask paths) and
   the SESSION_TOKEN_MISSING reject family logs at DEBUG, not INFO.
4. WS auth auto-registration from the ASGI configure path + the
   ``ws_auth_registered()`` accessor + the opt-out warning.
"""

from __future__ import annotations

import logging
import time
from types import SimpleNamespace

import pytest

from dash_clerk_auth import ClerkUser, averify_request, verify_user_sync
from dash_clerk_auth._clerk_client import _is_missing_session_token


SECRET = "test-session-secret-v09"

# The real shape of a stock Clerk session JWT payload — no email, no name.
def _emailless_payload(sub="user_39nwblQcdKZbLmjBKDGISkPY4kT"):
    return {
        "azp": "http://127.0.0.1:8598",
        "exp": time.time() + 600,
        "iss": "https://fine-rhino-96.clerk.accounts.dev",
        "sid": "sess_test",
        "sts": "active",
        "sub": sub,
        "v": 2,
    }


class _Users:
    def __init__(self, state):
        self.state = state

    def get(self, *, user_id):
        self.state["get_calls"] += 1
        if self.state.get("get_raises"):
            raise RuntimeError("clerk users.get unavailable")
        return self.state.get("user_obj", {"id": user_id})


class _MockSyncClient:
    def __init__(self, state):
        self.state = state
        self.users = _Users(state)

    def authenticate_request(self, request, options):
        self.state["auth_calls"] += 1
        return SimpleNamespace(
            is_signed_in=self.state["signed_in"],
            payload=self.state["payload"],
            reason=self.state.get("reason", ""),
        )


@pytest.fixture
def sync_clerk(monkeypatch):
    state = {
        "signed_in": True,
        "payload": _emailless_payload(),
        "auth_calls": 0,
        "get_calls": 0,
        "user_obj": {
            "id": "user_39nwblQcdKZbLmjBKDGISkPY4kT",
            "email": "owner@2plot.ai",
            "first_name": "Pip",
            "last_name": "Install",
            "image_url": "https://img.clerk.com/x.png",
        },
    }
    from dash_clerk_auth import _clerk_client

    monkeypatch.setattr(_clerk_client, "get_sync_client", lambda: _MockSyncClient(state))
    return state


# ---------------------------------------------------------------------------
# Issue 1 — email enrichment
# ---------------------------------------------------------------------------
def test_verify_sync_enriches_emailless_jwt(sync_clerk):
    user = verify_user_sync(headers={"authorization": "Bearer t1"})
    assert user is not None
    assert user.email == "owner@2plot.ai"
    assert user.first_name == "Pip"
    assert user.image_url == "https://img.clerk.com/x.png"
    assert sync_clerk["get_calls"] == 1


def test_enrichment_sticky_across_token_rotation(sync_clerk):
    """JWT rotates every ~60s — the users.get must NOT repeat per rotation."""
    a = verify_user_sync(headers={"authorization": "Bearer rotation-1"})
    b = verify_user_sync(headers={"authorization": "Bearer rotation-2"})
    assert a.email == b.email == "owner@2plot.ai"
    assert sync_clerk["auth_calls"] == 2  # different cache keys → two verifies
    assert sync_clerk["get_calls"] == 1  # but ONE users.get, remembered per user_id


def test_jti_cache_stores_enriched_user(sync_clerk):
    headers = {"authorization": "Bearer same"}
    verify_user_sync(headers=headers)
    cached = verify_user_sync(headers=headers)
    assert sync_clerk["auth_calls"] == 1  # second call came from the jti cache
    assert cached.email == "owner@2plot.ai"  # and the CACHED verdict has the email


def test_no_fetch_when_jwt_carries_email(sync_clerk):
    """Instances that customise the session token skip enrichment entirely."""
    sync_clerk["payload"] = {**_emailless_payload(), "email": "claim@2plot.ai"}
    user = verify_user_sync(headers={"authorization": "Bearer t"})
    assert user.email == "claim@2plot.ai"
    assert sync_clerk["get_calls"] == 0


def test_enrichment_fetch_failure_is_not_sticky(sync_clerk):
    sync_clerk["get_raises"] = True
    user = verify_user_sync(headers={"authorization": "Bearer t1"})
    assert user is not None and user.email is None  # verified, just un-enriched

    # Clerk recovers — the next slow-path verify retries the fetch.
    sync_clerk["get_raises"] = False
    user2 = verify_user_sync(headers={"authorization": "Bearer t2"})
    assert user2.email == "owner@2plot.ai"


def test_enrichment_remembers_email_less_accounts(sync_clerk):
    """A user with no email at Clerk (phone-only) must not re-fetch forever."""
    sync_clerk["user_obj"] = {"id": "user_39nwblQcdKZbLmjBKDGISkPY4kT"}
    a = verify_user_sync(headers={"authorization": "Bearer t1"})
    b = verify_user_sync(headers={"authorization": "Bearer t2"})
    assert a.email is None and b.email is None
    assert sync_clerk["get_calls"] == 1  # "no email" was remembered too


async def test_averify_enriches_emailless_jwt(patch_clerk_async):
    patch_clerk_async(
        payload=_emailless_payload(),
        user_by_id={
            "id": "user_39nwblQcdKZbLmjBKDGISkPY4kT",
            "email": "owner@2plot.ai",
        },
    )
    user = await averify_request(headers={"authorization": "Bearer t"})
    assert user is not None
    assert user.email == "owner@2plot.ai"


# ---------------------------------------------------------------------------
# Issue 2 — flask before_request slow path
# ---------------------------------------------------------------------------
@pytest.fixture
def flask_client(tmp_path, sync_clerk):
    flask = pytest.importorskip("flask")
    import dash_clerk_auth as m

    saved = dict(m._clerk_config)
    m._clerk_config.update(
        {
            "initialized": True,
            "session_secret": SECRET,
            "session_lifetime_days": 7,
            "enable_proxy_fix": False,
            "billing_enabled": False,
            "authorized_parties": [],
            "clerk_client": None,
        }
    )

    server = flask.Flask(__name__)
    server.config["SESSION_FILE_DIR"] = str(tmp_path / "fs")
    m._configure_flask_app(SimpleNamespace(server=server))

    @server.route("/whoami")
    def whoami():
        user = getattr(flask.g, "clerk_user", None)
        return flask.jsonify(
            {
                "user_id": user.user_id if user else None,
                "email": user.email if user else None,
            }
        )

    client = server.test_client()
    yield client
    m._clerk_config.clear()
    m._clerk_config.update(saved)


def test_flask_slow_path_establishes_identity_and_mints_cookie(flask_client, sync_clerk):
    # A signed-in browser carries __session; nothing ever POSTed a token to
    # /api/auth/session (the v0.5→v0.7 regression). The before_request slow
    # path alone must resolve identity AND mint __dca_identity.
    flask_client.set_cookie("__session", "jwt-from-clerk-js")
    resp = flask_client.get("/whoami")
    assert resp.get_json() == {
        "user_id": "user_39nwblQcdKZbLmjBKDGISkPY4kT",
        "email": "owner@2plot.ai",
    }
    assert sync_clerk["auth_calls"] == 1

    # Cookie round-trip: the minted value must decode and carry the email.
    minted = flask_client.get_cookie("__dca_identity")
    assert minted is not None
    from dash_clerk_auth._identity_cookie import verify as identity_verify

    cached = identity_verify(minted.value, SECRET, 7 * 24 * 3600)
    assert isinstance(cached, ClerkUser)
    assert cached.email == "owner@2plot.ai"


def test_flask_fast_path_survives_clerk_outage(flask_client, sync_clerk):
    flask_client.set_cookie("__session", "jwt-from-clerk-js")
    flask_client.get("/whoami")
    assert sync_clerk["auth_calls"] == 1

    # JWT rotated away and Clerk is now rejecting everything — the signed
    # identity cookie alone must keep the user authenticated.
    flask_client.delete_cookie("__session")
    sync_clerk["signed_in"] = False
    resp = flask_client.get("/whoami")
    assert resp.get_json()["email"] == "owner@2plot.ai"
    assert sync_clerk["auth_calls"] == 1  # no Clerk roundtrip on the fast path


def test_flask_idle_client_uat_only_skips_verify(flask_client, sync_clerk):
    flask_client.set_cookie("__client_uat", "1748000000")
    resp = flask_client.get("/whoami")
    assert resp.get_json() == {"user_id": None, "email": None}
    assert sync_clerk["auth_calls"] == 0  # guaranteed-reject roundtrip skipped


def test_flask_skip_prefixes_never_verify(flask_client, sync_clerk):
    flask_client.set_cookie("__session", "jwt-from-clerk-js")
    flask_client.get("/assets/style.css")
    flask_client.get("/_dash-component-suites/dash/dash.js")
    assert sync_clerk["auth_calls"] == 0


def test_flask_dash_layout_still_resolves_identity(sync_clerk, flask_client):
    """/_dash-layout must NOT be in the flask skip list: the layout-hook
    store pre-hydration and dynamic root layouts read current_user() while
    that route is served. Skipping it would bring back the first-paint
    anonymous flash that v0.7 fixed."""
    flask_client.set_cookie("__session", "jwt-from-clerk-js")
    flask_client.get("/_dash-layout")  # 404 here (no Dash app) — hook still runs
    assert sync_clerk["auth_calls"] == 1


def test_api_auth_session_route_enriches(flask_client, sync_clerk):
    import dash_clerk_auth as m

    # The route uses the v0.5 config client for the verify itself…
    m._clerk_config["clerk_client"] = _MockSyncClient(sync_clerk)
    resp = flask_client.post("/api/auth/session", json={"token": "tok"})
    data = resp.get_json()
    assert data["authenticated"] is True
    # …but the email must come from enrichment (the JWT payload has none).
    assert data["user"]["email"] == "owner@2plot.ai"


# ---------------------------------------------------------------------------
# Issue 5 — idle-state log quieting
# ---------------------------------------------------------------------------
def test_session_token_missing_is_recognised():
    try:
        from clerk_backend_api.security.types import AuthErrorReason
    except ImportError:
        from clerk_backend_api.security.authenticaterequest import AuthErrorReason

    assert _is_missing_session_token(AuthErrorReason.SESSION_TOKEN_MISSING) is True
    assert _is_missing_session_token("session-token-missing: no __session") is True
    assert _is_missing_session_token("token-expired") is False
    assert _is_missing_session_token(None) is False


def test_session_token_missing_logs_debug_not_info(sync_clerk, caplog):
    sync_clerk["signed_in"] = False
    sync_clerk["reason"] = "session-token-missing: could not retrieve"
    with caplog.at_level(logging.DEBUG, logger="dash_clerk_auth._clerk_client"):
        assert verify_user_sync(headers={"authorization": "Bearer t"}) is None
    rejects = [r for r in caplog.records if "Clerk verify rejected" in r.message]
    assert rejects and all(r.levelno == logging.DEBUG for r in rejects)


def test_other_reject_reasons_still_log_info(sync_clerk, caplog):
    sync_clerk["signed_in"] = False
    sync_clerk["reason"] = "token-expired"
    with caplog.at_level(logging.DEBUG, logger="dash_clerk_auth._clerk_client"):
        assert verify_user_sync(headers={"authorization": "Bearer t"}) is None
    rejects = [r for r in caplog.records if "Clerk verify rejected" in r.message]
    assert rejects and all(r.levelno == logging.INFO for r in rejects)


def _scope(cookie: str):
    return {
        "type": "http",
        "method": "GET",
        "path": "/traffic",
        "scheme": "http",
        "headers": [(b"host", b"localhost"), (b"cookie", cookie.encode())],
    }


async def test_asgi_idle_client_uat_only_skips_clerk(monkeypatch):
    from dash_clerk_auth import _asgi

    async def _boom(**kwargs):
        raise AssertionError("averify_request must not be called for idle requests")

    monkeypatch.setattr(_asgi, "averify_request", _boom)
    mw = _asgi.ClerkASGIMiddleware(None, session_secret=SECRET)
    user, _cookies, fresh = await mw._resolve_identity(
        _scope("__client_uat=1748000000; __refresh_x=abc")
    )
    assert user is None and fresh is False


async def test_asgi_session_cookie_still_hits_slow_path(monkeypatch):
    from dash_clerk_auth import _asgi

    expected = ClerkUser(user_id="u_1", email="owner@2plot.ai")

    async def _ok(**kwargs):
        return expected

    monkeypatch.setattr(_asgi, "averify_request", _ok)
    mw = _asgi.ClerkASGIMiddleware(None, session_secret=SECRET)
    user, _cookies, fresh = await mw._resolve_identity(_scope("__session=jwt"))
    assert user is expected and fresh is True


# ---------------------------------------------------------------------------
# Issues 3 + 4 — WS auth auto-registration, sources, accessor
# ---------------------------------------------------------------------------
async def test_ws_resolve_sources(monkeypatch):
    from dash_clerk_auth import _ws

    async def _boom(**kwargs):
        raise AssertionError("averify_request must not be called")

    monkeypatch.setattr(_ws, "averify_request", _boom)

    kw = dict(
        session_secret=SECRET,
        identity_cookie_max_age=3600,
        authorized_parties=None,
        billing_enabled=False,
    )

    # 1. Middleware already resolved → "state".
    bound = ClerkUser(user_id="u_1", email="owner@2plot.ai")
    ws = SimpleNamespace(state=SimpleNamespace(clerk_user=bound), headers={}, cookies={})
    assert await _ws._resolve_user_for_socket(ws, **kw) == (bound, "state")

    # 2. Only __client_uat → idle, NO Clerk roundtrip.
    ws = SimpleNamespace(
        state=SimpleNamespace(), headers={}, cookies={"__client_uat": "1"}
    )
    assert await _ws._resolve_user_for_socket(ws, **kw) == (None, "idle")

    # 3. Nothing at all → anonymous.
    ws = SimpleNamespace(state=SimpleNamespace(), headers={}, cookies={})
    assert await _ws._resolve_user_for_socket(ws, **kw) == (None, "anonymous")


def _fastapi_config(m, **overrides):
    cfg = {
        "initialized": True,
        "clerk_secret_key": "sk_test_dummy",
        "session_secret": SECRET,
        "session_lifetime_days": 7,
        "billing_enabled": False,
        "authorized_parties": [],
        "on_unverified": "forbidden",
        "verify_timeout": 5.0,
        "websocket_auth": True,
    }
    cfg.update(overrides)
    m._clerk_config.update(cfg)


def test_fastapi_configure_autoregisters_ws_auth():
    starlette = pytest.importorskip("starlette.applications")
    import dash_clerk_auth as m

    saved = dict(m._clerk_config)
    try:
        _fastapi_config(m)
        app = SimpleNamespace(server=starlette.Starlette(), _websocket_callbacks=False)
        m._configure_fastapi_app(app)
        assert m.ws_auth_registered() is True
    finally:
        m._clerk_config.clear()
        m._clerk_config.update(saved)


def test_fastapi_configure_warns_when_ws_auth_opted_out(caplog):
    starlette = pytest.importorskip("starlette.applications")
    import dash_clerk_auth as m

    saved = dict(m._clerk_config)
    try:
        _fastapi_config(m, websocket_auth=False)
        app = SimpleNamespace(server=starlette.Starlette(), _websocket_callbacks=True)
        with caplog.at_level(logging.WARNING, logger="dash_clerk_auth"):
            m._configure_fastapi_app(app)
        assert any(
            "WebSocket auth is not registered" in r.message for r in caplog.records
        )
    finally:
        m._clerk_config.clear()
        m._clerk_config.update(saved)
