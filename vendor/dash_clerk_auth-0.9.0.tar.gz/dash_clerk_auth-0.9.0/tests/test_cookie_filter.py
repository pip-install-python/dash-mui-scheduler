"""Multi-Clerk-app cookie hygiene.

When developing locally on a single hostname (``localhost`` /
``127.0.0.1``), it's normal to have signed into several Clerk apps —
each one drops its own ``__session_<suffix>`` cookie. Browsers send all
of them on every request. Clerk's backend SDK reads the FIRST matching
``__session*`` cookie it sees, which can be from a totally different app
than the one this server is configured for. That manifests as a
``JWK_KID_MISMATCH`` rejection on every request even when the canonical
``__session`` cookie is perfectly valid.

The filter in :func:`_filter_other_app_clerk_cookies` strips the
suffixed variants so the SDK falls through to the canonical no-suffix
cookies, which Clerk JS always maintains for the active app.
"""

from __future__ import annotations

from dash_clerk_auth._clerk_client import _filter_other_app_clerk_cookies as flt


def test_strips_suffixed_session_cookies():
    raw = "__session=GOOD; __session_IJzHnUCc=OTHER; __session_P7jZG8kJ=DUP"
    out = flt(raw)
    assert "__session=GOOD" in out
    assert "__session_IJzHnUCc" not in out
    assert "__session_P7jZG8kJ" not in out


def test_strips_suffixed_uat_cookies():
    raw = "__client_uat=A; __client_uat_IJzHnUCc=B; __client_uat_P7jZG8kJ=C"
    out = flt(raw)
    assert "__client_uat=A" in out
    assert "__client_uat_IJzHnUCc" not in out
    assert "__client_uat_P7jZG8kJ" not in out


def test_strips_clerk_db_jwt_variants_but_keeps_canonical():
    raw = "__clerk_db_jwt=keep; __clerk_db_jwt_xyz=drop"
    out = flt(raw)
    assert "__clerk_db_jwt=keep" in out
    assert "__clerk_db_jwt_xyz" not in out


def test_leaves_unrelated_cookies_untouched():
    raw = "_cfuvid=keep; analytics=keep; foo_bar_baz=keep"
    assert flt(raw) == "_cfuvid=keep; analytics=keep; foo_bar_baz=keep"


def test_handles_empty_and_whitespace():
    assert flt("") == ""
    assert flt("   ") == ""
    assert flt("; ; ; ") == ""


def test_preserves_canonical_when_only_suffixed_present():
    """If only suffixed cookies are present, the result is empty — that's
    correct, because we'd rather Clerk see "no cookie" than the wrong app's
    cookie. The middleware then falls back to anonymous instead of returning
    a verdict for the wrong user."""
    raw = "__session_xyz=other; __client_uat_xyz=other"
    assert flt(raw) == ""


def test_full_live_payload_from_real_bug():
    """The exact cookie header that caused the v0.7 KID_MISMATCH bug
    (single live app on 127.0.0.1 with stale cookies from a second
    unrelated Clerk dev app left in the browser)."""
    raw = (
        "__client_uat=1778783182; "
        "__client_uat_IJzHnUCc=1778302360; "
        "__client_uat_P7jZG8kJ=1778783182; "
        "__session=GOOD_JWT; "
        "__session_IJzHnUCc=BAD_JWT_FROM_OTHER_APP; "
        "__session_P7jZG8kJ=GOOD_JWT_DUPLICATE"
    )
    out = flt(raw)
    assert "__session=GOOD_JWT" in out
    assert "__client_uat=1778783182" in out
    # Critically — the wrong-app cookie is gone.
    assert "BAD_JWT_FROM_OTHER_APP" not in out
    assert "IJzHnUCc" not in out
    assert "P7jZG8kJ" not in out
