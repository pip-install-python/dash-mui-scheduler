"""Per-renderer WebSocket identity registry — bounded TTL cache.

The registry is the bridge between the WS connect/message hooks (run in
the asyncio task) and the per-callback dispatch (run in a thread pool
where ContextVars don't propagate). Tests verify the basic semantics
without booting Dash itself — Dash 4.2 is not on the test classpath.
"""

from __future__ import annotations

import time

import pytest

from dash_clerk_auth import ClerkUser
from dash_clerk_auth import _ws_registry
from dash_clerk_auth._ws_registry import attach, detach, lookup


@pytest.fixture(autouse=True)
def _reset_registry():
    _ws_registry._reset_for_tests()
    yield
    _ws_registry._reset_for_tests()


def _user(uid: str) -> ClerkUser:
    return ClerkUser.from_jwt_payload({"sub": uid})


def test_attach_then_lookup_returns_user():
    u = _user("u_a")
    attach("rid-1", u)
    assert lookup("rid-1") is u


def test_lookup_unknown_renderer_returns_none():
    assert lookup("never-attached") is None
    assert lookup(None) is None


def test_attach_with_none_renderer_id_is_noop():
    attach(None, _user("nope"))
    assert lookup("nope") is None
    assert len(_ws_registry._REGISTRY) == 0


def test_attach_overwrites_previous_user():
    attach("rid-x", _user("first"))
    attach("rid-x", _user("second"))
    assert lookup("rid-x").user_id == "second"


def test_anonymous_user_can_be_attached():
    """on_anonymous='allow' attaches None — registry must store the absence."""
    attach("rid-anon", None)
    # The 'attached None' state means "we know this connection is anonymous".
    # lookup returns None either way; that's correct.
    assert lookup("rid-anon") is None


def test_detach_removes_entry():
    attach("rid-d", _user("u"))
    detach("rid-d")
    assert lookup("rid-d") is None


def test_renderer_id_from_callback_context_returns_none_outside_callback():
    """Without a Dash callback context, the helper falls back to None."""
    from dash_clerk_auth._ws_registry import renderer_id_from_callback_context

    assert renderer_id_from_callback_context() is None


def test_size_cap_evicts_oldest():
    """Once over the cap, the oldest 25% are dropped."""
    # Bypass _MAX_ENTRIES to keep the test fast.
    original_max = _ws_registry._MAX_ENTRIES
    _ws_registry._MAX_ENTRIES = 8
    try:
        for i in range(12):
            attach(f"rid-{i}", _user(f"u{i}"))
        # We attached 12, cap is 8. After the trip, the 25% oldest (2 of 8)
        # should have been dropped — meaning we have <= 8 entries.
        assert len(_ws_registry._REGISTRY) <= 8
        # Most recent attachment definitely still present.
        assert lookup("rid-11") is not None
    finally:
        _ws_registry._MAX_ENTRIES = original_max


# ---------------------------------------------------------------------------
# Concurrency — main-loop attach() races worker-thread lookup() under eviction.
# Without the lock this raised "dictionary changed size during iteration".
# ---------------------------------------------------------------------------
def test_concurrent_attach_lookup_under_eviction_never_raises():
    import threading

    original_max = _ws_registry._MAX_ENTRIES
    _ws_registry._MAX_ENTRIES = 16  # tiny cap so eviction fires constantly
    errors: list = []
    stop = threading.Event()

    def writer(base: int):
        try:
            i = 0
            while not stop.is_set():
                attach(f"w{base}-{i}", _user(f"u{base}-{i}"))
                i += 1
                if i > 2000:
                    break
        except Exception as exc:  # pragma: no cover — the bug we're guarding
            errors.append(exc)

    def reader(base: int):
        try:
            i = 0
            while not stop.is_set():
                lookup(f"w{(base + 1) % 4}-{i % 50}")
                i += 1
                if i > 2000:
                    break
        except Exception as exc:  # pragma: no cover
            errors.append(exc)

    threads = [threading.Thread(target=writer, args=(b,)) for b in range(4)]
    threads += [threading.Thread(target=reader, args=(b,)) for b in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
    stop.set()

    assert not errors, f"registry raised under concurrency: {errors[:3]}"
    # And it stayed bounded.
    assert len(_ws_registry._REGISTRY) <= _ws_registry._MAX_ENTRIES
    _ws_registry._MAX_ENTRIES = original_max


# ---------------------------------------------------------------------------
# Version-resilient renderer_id resolution across Dash 4.2.x accessor skew.
# ---------------------------------------------------------------------------
def _fake_dash_callback_context(monkeypatch, fake_ctx):
    """Install ``fake_ctx`` as ``dash.callback_context`` for the duration."""
    import dash

    monkeypatch.setattr(dash, "callback_context", fake_ctx, raising=False)


def test_renderer_id_resolves_via_websocket_property(monkeypatch):
    """rc3 / 4.2.0 final: ``ctx.websocket`` property exposes ``_renderer_id``."""
    from types import SimpleNamespace
    from dash_clerk_auth._ws_registry import renderer_id_from_callback_context

    ws = SimpleNamespace(_renderer_id="rid-final")
    _fake_dash_callback_context(monkeypatch, SimpleNamespace(websocket=ws))
    assert renderer_id_from_callback_context() == "rid-final"


def test_renderer_id_resolves_via_legacy_get_websocket(monkeypatch):
    """rc1 / rc2: only a ``get_websocket()`` method existed (no property)."""
    from types import SimpleNamespace
    from dash_clerk_auth._ws_registry import renderer_id_from_callback_context

    ws = SimpleNamespace(_renderer_id="rid-rc1")

    class LegacyCtx:
        def get_websocket(self):
            return ws

    _fake_dash_callback_context(monkeypatch, LegacyCtx())
    assert renderer_id_from_callback_context() == "rid-rc1"


def test_renderer_id_falls_back_when_property_raises(monkeypatch):
    """A raising ``websocket`` property (no WS capability) must not crash."""
    from types import SimpleNamespace
    from dash_clerk_auth._ws_registry import renderer_id_from_callback_context

    ws = SimpleNamespace(_renderer_id="rid-fallback")

    class RaisingCtx:
        @property
        def websocket(self):
            raise RuntimeError("WebSocket callbacks not supported on this backend")

        def get_websocket(self):
            return ws

    _fake_dash_callback_context(monkeypatch, RaisingCtx())
    assert renderer_id_from_callback_context() == "rid-fallback"


def test_renderer_id_none_when_no_websocket(monkeypatch):
    from types import SimpleNamespace
    from dash_clerk_auth._ws_registry import renderer_id_from_callback_context

    _fake_dash_callback_context(monkeypatch, SimpleNamespace(websocket=None))
    assert renderer_id_from_callback_context() is None
