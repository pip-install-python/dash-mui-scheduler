"""ClerkASGIMiddleware — identity cookie fast path, mint on response, WS scope."""

from __future__ import annotations

import asyncio

import pytest
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from dash_clerk_auth import ClerkUser, current_user
from dash_clerk_auth._asgi import ClerkASGIMiddleware
from dash_clerk_auth._identity_cookie import (
    COOKIE_NAME as IDENTITY_COOKIE,
    mint,
)


SECRET = "test-secret-1234567890"


def _build_app(**mw_kwargs):
    async def whoami(request):
        u = current_user()
        return JSONResponse({"user_id": getattr(u, "user_id", None)})

    app = Starlette(routes=[Route("/whoami", whoami)])
    app.add_middleware(ClerkASGIMiddleware, **mw_kwargs)
    return app


def test_identity_cookie_short_circuits_clerk(patch_clerk_async):
    """When __dca_identity is present and signed, Clerk is never called."""
    calls = {"n": 0}

    class _CountingClient:
        async def authenticate_request_async(self, *a, **kw):
            calls["n"] += 1
            from types import SimpleNamespace

            return SimpleNamespace(is_signed_in=False, payload={}, reason="")

    from dash_clerk_auth import _clerk_client

    _clerk_client.get_async_client = lambda: _CountingClient()  # type: ignore

    user = ClerkUser.from_jwt_payload({"sub": "u_fast", "email": "x@y.z"})
    token = mint(user, SECRET)

    app = _build_app(session_secret=SECRET)
    with TestClient(app) as client:
        resp = client.get("/whoami", cookies={IDENTITY_COOKIE: token})
    assert resp.json()["user_id"] == "u_fast"
    assert calls["n"] == 0


def test_clerk_verify_sets_cookie_on_response(patch_clerk_async):
    """A successful slow-path verify mints the identity cookie on the response."""
    patch_clerk_async(payload={"sub": "u_slow"}, signed_in=True)

    app = _build_app(session_secret=SECRET)
    with TestClient(app) as client:
        resp = client.get("/whoami", cookies={"__session": "fake-token"})
    assert resp.json()["user_id"] == "u_slow"
    # Set-Cookie header present and well-formed.
    set_cookies = resp.headers.get_list("set-cookie")
    minted = [c for c in set_cookies if c.startswith(f"{IDENTITY_COOKIE}=")]
    assert minted, f"expected {IDENTITY_COOKIE} in Set-Cookie, got {set_cookies}"
    assert "HttpOnly" in minted[0]
    assert "SameSite=Lax" in minted[0]


def test_no_session_secret_skips_cookie_minting(patch_clerk_async):
    """When session_secret is unset, middleware works but doesn't mint."""
    patch_clerk_async(payload={"sub": "u_x"}, signed_in=True)
    app = _build_app(session_secret=None)
    with TestClient(app) as client:
        resp = client.get("/whoami", cookies={"__session": "tok"})
    assert resp.json()["user_id"] == "u_x"
    assert not any(
        c.startswith(f"{IDENTITY_COOKIE}=")
        for c in resp.headers.get_list("set-cookie")
    )


def test_tampered_cookie_falls_through_to_clerk(patch_clerk_async):
    """A bad signature on __dca_identity should NOT pass — Clerk decides."""
    patch_clerk_async(payload={"sub": "u_real"}, signed_in=True)
    app = _build_app(session_secret=SECRET)
    with TestClient(app) as client:
        resp = client.get(
            "/whoami",
            cookies={
                IDENTITY_COOKIE: "garbage-not-signed",
                "__session": "real-clerk-token",
            },
        )
    # Falls through to Clerk verify (which the fixture stubs to signed_in=u_real).
    assert resp.json()["user_id"] == "u_real"


def test_websocket_scope_resolves_user(patch_clerk_async):
    """ASGI middleware now handles type='websocket'; binds to scope state."""
    patch_clerk_async(payload={"sub": "u_ws"}, signed_in=True)

    captured = {"scope_state": None}

    async def inner(scope, receive, send):
        # Capture what the middleware bound onto scope state.
        if scope["type"] == "websocket":
            captured["scope_state"] = (scope.get("state") or {}).get("clerk_user")
            # Accept + close cleanly.
            msg = await receive()
            if msg.get("type") == "websocket.connect":
                await send({"type": "websocket.accept"})
            await send({"type": "websocket.close", "code": 1000})

    mw = ClerkASGIMiddleware(inner, session_secret=SECRET)

    async def run():
        scope = {
            "type": "websocket",
            "path": "/_dash-ws-callback",
            "headers": [(b"cookie", b"__session=fake")],
            "scheme": "ws",
            "server": ("localhost", 8000),
            "query_string": b"",
        }
        sent = []
        recv_queue = asyncio.Queue()
        await recv_queue.put({"type": "websocket.connect"})

        async def receive():
            return await recv_queue.get()

        async def send(msg):
            sent.append(msg)

        await mw(scope, receive, send)
        return sent

    sent = asyncio.run(run())
    assert captured["scope_state"] is not None
    assert captured["scope_state"].user_id == "u_ws"
    # Inner app accepted then closed.
    assert any(m["type"] == "websocket.accept" for m in sent)


def test_websocket_with_identity_cookie_skips_clerk(patch_clerk_async):
    """WS handshake with valid __dca_identity cookie doesn't roundtrip Clerk."""
    calls = {"n": 0}

    class _Counting:
        async def authenticate_request_async(self, *a, **kw):
            calls["n"] += 1
            from types import SimpleNamespace
            return SimpleNamespace(is_signed_in=False, payload={}, reason="")

    from dash_clerk_auth import _clerk_client

    _clerk_client.get_async_client = lambda: _Counting()  # type: ignore

    user = ClerkUser.from_jwt_payload({"sub": "u_ws_fast"})
    token = mint(user, SECRET)
    cookie_header = f"{IDENTITY_COOKIE}={token}".encode("latin-1")

    captured = {"user_id": None}

    async def inner(scope, receive, send):
        captured["user_id"] = getattr(
            (scope.get("state") or {}).get("clerk_user"), "user_id", None
        )
        msg = await receive()
        await send({"type": "websocket.accept"})
        await send({"type": "websocket.close", "code": 1000})

    mw = ClerkASGIMiddleware(inner, session_secret=SECRET)

    async def run():
        scope = {
            "type": "websocket",
            "path": "/_dash-ws-callback",
            "headers": [(b"cookie", cookie_header)],
            "scheme": "ws",
            "server": ("localhost", 8000),
            "query_string": b"",
        }
        recv_q = asyncio.Queue()
        await recv_q.put({"type": "websocket.connect"})
        await mw(scope, recv_q.get, lambda m: None if asyncio.iscoroutine(None) else None)

    # Use a simpler runner
    async def run2():
        scope = {
            "type": "websocket",
            "path": "/_dash-ws-callback",
            "headers": [(b"cookie", cookie_header)],
            "scheme": "ws",
            "server": ("localhost", 8000),
            "query_string": b"",
        }
        recv_q = asyncio.Queue()
        await recv_q.put({"type": "websocket.connect"})

        async def receive():
            return await recv_q.get()

        async def send(_):
            return None

        await mw(scope, receive, send)

    asyncio.run(run2())
    assert captured["user_id"] == "u_ws_fast"
    assert calls["n"] == 0


def test_x_forwarded_proto_https_marks_cookie_secure(patch_clerk_async):
    patch_clerk_async(payload={"sub": "u_sec"}, signed_in=True)
    app = _build_app(session_secret=SECRET)
    with TestClient(app) as client:
        resp = client.get(
            "/whoami",
            cookies={"__session": "tok"},
            headers={"X-Forwarded-Proto": "https"},
        )
    set_cookies = resp.headers.get_list("set-cookie")
    minted = [c for c in set_cookies if c.startswith(f"{IDENTITY_COOKIE}=")]
    assert minted and "Secure" in minted[0]
