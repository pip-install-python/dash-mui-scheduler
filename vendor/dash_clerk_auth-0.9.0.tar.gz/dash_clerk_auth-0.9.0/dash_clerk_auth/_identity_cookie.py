"""Signed identity cookie — verified-positive cache for the Clerk verdict.

The Clerk ``__session`` cookie is the source of truth for "who is this
user?", but verifying it against Clerk's JWKS on every request (and every
WebSocket message) is wasteful. This module mints a separate signed
cookie, ``__dca_identity``, that carries the projected ``ClerkUser`` dict
and a short TTL. Reading it requires only an HMAC verify (no I/O).

Lifecycle:

- After a successful ``averify_request`` against Clerk, callers mint a
  fresh ``__dca_identity`` cookie via :func:`mint`. The cookie's max age
  is bounded by the JWT ``exp`` so we never serve a cached identity past
  the underlying session's expiry.
- On every subsequent request (HTTP or WebSocket upgrade), the ASGI
  middleware checks ``__dca_identity`` first via :func:`verify`. A valid
  cookie short-circuits the Clerk roundtrip.
- ``/api/auth/signout`` emits :func:`clear_header` to evict the cookie
  client-side.

Signing uses :class:`itsdangerous.URLSafeTimedSerializer`, already a
transitive dep through Starlette ``SessionMiddleware`` (FastAPI/Quart)
and Flask. No new third-party requirement.
"""

from __future__ import annotations

import logging
from typing import Optional, Tuple

from ._user import ClerkUser

logger = logging.getLogger(__name__)


COOKIE_NAME = "__dca_identity"
_SALT = "dash-clerk-auth.identity.v1"


def _serializer(secret: str):
    """Lazy import of itsdangerous so Flask-only / no-cookie code paths
    don't pay the import cost. Fails loudly if itsdangerous is missing
    (it's pulled in transitively by both Flask and Starlette so this
    almost never happens in practice)."""
    try:
        from itsdangerous import URLSafeTimedSerializer
    except ImportError as exc:  # pragma: no cover — exercised on bare installs only
        raise RuntimeError(
            "dash-clerk-auth identity cookie requires `itsdangerous`. "
            "Install via `pip install itsdangerous` (or pull it in via the "
            "`flask` / `dash-clerk-auth[fastapi]` extras)."
        ) from exc
    return URLSafeTimedSerializer(secret, salt=_SALT)


def mint(user: ClerkUser, secret: str) -> str:
    """Return the signed cookie value carrying ``user``'s session dict.

    The token is opaque to the client — only this process (or another
    process with the same ``secret``) can verify it. Keep ``secret`` in
    sync across replicas.
    """
    if not secret:
        raise ValueError("session_secret is required to mint identity cookies")
    return _serializer(secret).dumps(user.to_session_dict())


def verify(token: str, secret: str, max_age: int) -> Optional[ClerkUser]:
    """Return the ``ClerkUser`` encoded in ``token`` if signed and fresh.

    Returns ``None`` for any failure mode — bad signature, expired,
    malformed payload. Callers should treat ``None`` as "fall through to
    the slow path (Clerk verify)".
    """
    if not token or not secret:
        return None
    try:
        data = _serializer(secret).loads(token, max_age=max_age)
    except Exception as exc:
        # itsdangerous raises BadSignature / SignatureExpired — both fine
        # to swallow at this layer; the caller falls through.
        logger.debug("identity cookie verify failed: %s", exc)
        return None
    if not isinstance(data, dict):
        return None
    try:
        return ClerkUser.from_session_dict(data)
    except Exception:  # pragma: no cover — defensive
        return None


def set_cookie_header(
    value: str,
    *,
    max_age: int,
    secure: bool = False,
    same_site: str = "Lax",
) -> Tuple[bytes, bytes]:
    """Build a raw ``(b"set-cookie", b"...")`` header tuple.

    Returned in raw-bytes form so it slots straight into an ASGI
    response's ``headers`` list. For Flask/Werkzeug callers, prefer
    :func:`flask_set_cookie_kwargs`.
    """
    parts = [
        f"{COOKIE_NAME}={value}",
        f"Max-Age={int(max_age)}",
        "Path=/",
        "HttpOnly",
        f"SameSite={same_site}",
    ]
    if secure:
        parts.append("Secure")
    return (b"set-cookie", "; ".join(parts).encode("latin-1"))


def clear_cookie_header(*, secure: bool = False) -> Tuple[bytes, bytes]:
    """Build a header that evicts the cookie on the client."""
    parts = [
        f"{COOKIE_NAME}=",
        "Max-Age=0",
        "Path=/",
        "HttpOnly",
        "SameSite=Lax",
    ]
    if secure:
        parts.append("Secure")
    return (b"set-cookie", "; ".join(parts).encode("latin-1"))


def flask_set_cookie_kwargs(
    value: str,
    *,
    max_age: int,
    secure: bool = False,
    same_site: str = "Lax",
) -> dict:
    """Kwargs for ``flask.Response.set_cookie(name, value, **kwargs)``."""
    return {
        "key": COOKIE_NAME,
        "value": value,
        "max_age": max_age,
        "path": "/",
        "httponly": True,
        "secure": secure,
        "samesite": same_site,
    }


def flask_clear_cookie_kwargs(*, secure: bool = False) -> dict:
    return {
        "key": COOKIE_NAME,
        "value": "",
        "max_age": 0,
        "path": "/",
        "httponly": True,
        "secure": secure,
        "samesite": "Lax",
    }


def bounded_max_age(jwt_exp: Optional[float], cap_seconds: int) -> int:
    """Return ``min(cap_seconds, jwt_exp - now)`` bounded to a safe range.

    Cookies must never outlive the JWT they cache. ``cap_seconds`` is the
    deployer-chosen ceiling (typically ``session_lifetime_days * 86400``).
    """
    import time

    cap = max(60, int(cap_seconds))
    if jwt_exp is None:
        return cap
    remaining = int(float(jwt_exp) - time.time())
    if remaining <= 0:
        return 0
    return min(cap, remaining)
