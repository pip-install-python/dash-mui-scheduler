"""
dash-clerk-auth — Demo Application

A multi-page explorer that showcases every aspect of the hook through
limited working examples. Modeled after the dash-mui-charts demo layout:
AppShell with a sidebar, dark/light toggle, and one concept per page.

Run from the repo root:
    python examples/app.py

Environment (.env or export before running):
    CLERK_SECRET_KEY=sk_test_...
    CLERK_PUBLISHABLE_KEY=pk_test_...
    CLERK_SIGN_IN_URL=https://your-app.clerk.accounts.dev/sign-in
    FLASK_SECRET_KEY=<random>
    DEBUG=True

If the Clerk keys are missing the app still boots in "docs-only" mode so
you can review the limited working examples without a Clerk account.
"""

import os
import sys

import dash
import dash_mantine_components as dmc
from dash import Dash, html, dcc, Input, Output, State, callback, clientside_callback, page_container
from dash_iconify import DashIconify

# Load .env if python-dotenv is available
try:
    from dotenv import load_dotenv, find_dotenv
    load_dotenv(find_dotenv(), override=True)
except ImportError:
    pass

# Make the examples folder importable so `pages/` resolves when run from any cwd
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

# ---------------------------------------------------------------------------
# Clerk registration — runs BEFORE Dash() so hooks fire on app construction
# ---------------------------------------------------------------------------
CLERK_SECRET_KEY = os.getenv("CLERK_SECRET_KEY")
CLERK_PUBLISHABLE_KEY = os.getenv("CLERK_PUBLISHABLE_KEY")
CLERK_SIGN_IN_URL = os.getenv("CLERK_SIGN_IN_URL")
CLERK_CONFIGURED = all([CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY, CLERK_SIGN_IN_URL])

CLERK_AVAILABLE = False
CLERK_ERROR = None

if CLERK_CONFIGURED:
    try:
        from dash_clerk_auth import register_clerk_auth

        register_clerk_auth(
            clerk_secret_key=CLERK_SECRET_KEY,
            clerk_publishable_key=CLERK_PUBLISHABLE_KEY,
            clerk_sign_in_url=CLERK_SIGN_IN_URL,
            debug=os.getenv("DEBUG", "").lower() in ("true", "1", "yes"),
            show_debug_panel=os.getenv("DEBUG", "").lower() in ("true", "1", "yes"),
            enable_billing=True,
            # Headless mode: the hook skips its fixed top-right avatar so we
            # can drop create_clerk_menu() into the AppShellHeader below.
            headless=True,
        )
        CLERK_AVAILABLE = True
    except Exception as exc:
        CLERK_ERROR = str(exc)

import dash_clerk_auth as _clerk_pkg  # noqa: E402 — after registration
CLERK_VERSION = getattr(_clerk_pkg, "__version__", "unknown")

# Slot for the Clerk avatar + dropdown, placed inline inside AppShellHeader.
# When Clerk isn't configured (docs-only mode) we render a small "Not signed
# in" pill instead so the header layout stays balanced.
if CLERK_AVAILABLE:
    from dash_clerk_auth import create_clerk_menu
    _clerk_menu_slot = create_clerk_menu()
else:
    _clerk_menu_slot = dmc.Tooltip(
        dmc.Badge(
            "Clerk not configured",
            color="gray",
            variant="light",
            leftSection=DashIconify(icon="tabler:plug-off", width=12),
        ),
        label="Set CLERK_SECRET_KEY / PUBLISHABLE_KEY / SIGN_IN_URL to enable sign-in",
        position="bottom-end",
        withArrow=True,
    )

# ---------------------------------------------------------------------------
# Dash app
# ---------------------------------------------------------------------------
app = Dash(
    __name__,
    use_pages=True,
    pages_folder=os.path.join(_THIS_DIR, "pages"),
    external_stylesheets=[dmc.styles.ALL],
    suppress_callback_exceptions=True,
)
server = app.server
app.title = "dash-clerk-auth — Demo"

if CLERK_AVAILABLE:
    from dash_clerk_auth import configure_app
    configure_app(app)

# ---------------------------------------------------------------------------
# Navigation — groups and leaves. itemId is the path for leaves.
# ---------------------------------------------------------------------------
NAV_SECTIONS = [
    {
        "label": "Overview",
        "items": [
            {"path": "/", "label": "Home", "icon": "tabler:home"},
            {"path": "/quickstart", "label": "Quickstart", "icon": "tabler:rocket"},
            {"path": "/changelog", "label": "Changelog", "icon": "tabler:history"},
        ],
    },
    {
        "label": "Configuration",
        "items": [
            {"path": "/register-props", "label": "register_clerk_auth props", "icon": "tabler:settings-cog"},
            {"path": "/auth-store", "label": "clerk-auth-store", "icon": "tabler:database"},
            {"path": "/debug-panel", "label": "Debug panel", "icon": "tabler:bug"},
        ],
    },
    {
        "label": "Decorators",
        "items": [
            {"path": "/require-auth", "label": "@require_auth", "icon": "tabler:lock"},
            {"path": "/require-plan", "label": "@require_plan", "icon": "tabler:diamond"},
            {"path": "/require-feature", "label": "@require_feature", "icon": "tabler:key"},
        ],
    },
    {
        "label": "Utilities & billing",
        "items": [
            {"path": "/user-info", "label": "User info helpers", "icon": "tabler:user-circle"},
            {"path": "/billing", "label": "Clerk billing", "icon": "tabler:credit-card"},
        ],
    },
    {
        "label": "Architecture",
        "items": [
            {"path": "/multi-domain", "label": "Multi-domain (galaxy)", "icon": "tabler:satellite"},
        ],
    },
]


def _nav_section(section):
    return dmc.Stack(
        [
            dmc.Text(
                section["label"].upper(),
                size="xs",
                c="dimmed",
                fw=600,
                style={"letterSpacing": "0.08em", "padding": "0 12px", "marginTop": "16px"},
            ),
            *[
                dmc.NavLink(
                    id={"type": "nav-link", "path": item["path"]},
                    label=item["label"],
                    leftSection=DashIconify(icon=item["icon"], width=18),
                    href=item["path"],
                    variant="light",
                    active="exact",
                    style={"borderRadius": "8px", "margin": "2px 8px"},
                )
                for item in section["items"]
            ],
        ],
        gap=2,
    )


# ---------------------------------------------------------------------------
# Header + navbar
# ---------------------------------------------------------------------------
_status_badge_color = "green" if CLERK_AVAILABLE else ("red" if CLERK_ERROR else "gray")
_status_badge_text = "Clerk active" if CLERK_AVAILABLE else ("Clerk error" if CLERK_ERROR else "Docs-only")

header = dmc.AppShellHeader(
    dmc.Group(
        [
            dmc.Group(
                [
                    dmc.Burger(id="burger", size="sm", hiddenFrom="sm", opened=False),
                    DashIconify(icon="tabler:shield-lock", width=26, color="#049ff2"),
                    dmc.Stack(
                        [
                            dmc.Text("dash-clerk-auth", fw=700, size="md", style={"lineHeight": 1.1}),
                            dmc.Text(f"v{CLERK_VERSION}", size="xs", c="dimmed", style={"lineHeight": 1}),
                        ],
                        gap=2,
                    ),
                    dmc.Badge(
                        _status_badge_text,
                        color=_status_badge_color,
                        variant="light",
                        size="sm",
                        leftSection=DashIconify(
                            icon="tabler:check" if CLERK_AVAILABLE else "tabler:alert-circle",
                            width=12,
                        ),
                        visibleFrom="xs",
                    ),
                ],
                gap="sm",
            ),
            dmc.Group(
                [
                    html.A(
                        dmc.ActionIcon(
                            DashIconify(icon="mdi:github", width=22),
                            variant="subtle",
                            color="gray",
                            size="lg",
                        ),
                        href="https://github.com/pip-install-python/dash-clerk-auth",
                        target="_blank",
                        title="GitHub repository",
                    ),
                    html.A(
                        dmc.ActionIcon(
                            DashIconify(icon="tabler:book", width=22),
                            variant="subtle",
                            color="gray",
                            size="lg",
                        ),
                        href="https://clerk.com/docs",
                        target="_blank",
                        title="Clerk docs",
                    ),
                    # Clerk avatar + dropdown, embedded in the header instead
                    # of floating. Requires register_clerk_auth(headless=True)
                    # above so the hook doesn't ALSO inject a fixed-position
                    # copy (that would create duplicate clerk-user-avatar ids).
                    _clerk_menu_slot,
                ],
                gap="xs",
            ),
        ],
        justify="space-between",
        h="100%",
        px="md",
        style={"flex": 1},
    )
)

navbar = dmc.AppShellNavbar(
    html.Div(
        [
            html.Div(
                [_nav_section(s) for s in NAV_SECTIONS],
                style={"flex": "1 1 0", "overflowY": "auto", "padding": "8px 0"},
            ),
            dmc.Divider(),
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:sun", width=16),
                            dmc.Switch(id="theme-switch", size="sm", persistence=True),
                            DashIconify(icon="tabler:moon", width=16),
                        ],
                        justify="center",
                        gap="xs",
                    ),
                    dmc.Text(
                        "Pip Install Python LLC",
                        size="xs",
                        c="dimmed",
                        ta="center",
                    ),
                ],
                gap="xs",
                p="sm",
            ),
        ],
        style={"display": "flex", "flexDirection": "column", "height": "100%"},
    ),
    p=0,
)

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
app.layout = dmc.MantineProvider(
    children=[
        dmc.AppShell(
            [
                header,
                navbar,
                dmc.AppShellMain(
                    dmc.Container(page_container, size="lg", py="lg"),
                ),
            ],
            header={"height": 60},
            navbar={"width": 280, "breakpoint": "sm", "collapsed": {"mobile": True}},
            padding="md",
            id="appshell",
        ),
    ],
    id="mantine-provider",
    defaultColorScheme="light",
)

# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------
# Theme toggle → set data-mantine-color-scheme (Clerk glass styles key off it)
clientside_callback(
    """
    (checked) => {
        const scheme = checked ? 'dark' : 'light';
        document.documentElement.setAttribute('data-mantine-color-scheme', scheme);
        return scheme;
    }
    """,
    Output("mantine-provider", "forceColorScheme"),
    Input("theme-switch", "checked"),
)

# Mobile burger → collapse the navbar
@callback(
    Output("appshell", "navbar"),
    Input("burger", "opened"),
    State("appshell", "navbar"),
)
def _toggle_navbar(opened, config):
    config = dict(config or {})
    config["collapsed"] = {"mobile": not opened}
    return config


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------
def _print_boot_banner():
    print("=" * 72)
    print(f"  dash-clerk-auth demo  ·  package v{CLERK_VERSION}")
    print("=" * 72)
    if CLERK_AVAILABLE:
        print("  Clerk: ACTIVE — sign-in avatar embedded in the AppShellHeader.")
    elif CLERK_ERROR:
        print(f"  Clerk: ERROR during register_clerk_auth: {CLERK_ERROR}")
        print("         The app will still serve the doc pages.")
    else:
        print("  Clerk: NOT CONFIGURED. Set these env vars to enable sign-in:")
        print("    CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY, CLERK_SIGN_IN_URL")
        print("  The app is running in docs-only mode — every page still renders.")
    print("=" * 72)
    print("  Starting on http://localhost:8050")
    print("=" * 72)


if __name__ == "__main__":
    _print_boot_banner()
    app.run(debug=True, host="0.0.0.0", port=8050)