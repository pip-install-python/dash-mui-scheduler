"""
Home page — landing overview of the dash-clerk-auth hook.

Shows what the package does, how to install it, and a grid of links to every
limited-working-example elsewhere in the demo.
"""

import dash
import dash_mantine_components as dmc
from dash import html, dcc
from dash_iconify import DashIconify

dash.register_page(__name__, path="/", name="Home", order=0)

INSTALL = "pip install 'dash-clerk-auth>=0.7.0'"

QUICKSTART = """from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app, create_clerk_menu

register_clerk_auth(
    clerk_secret_key="sk_test_...",
    clerk_publishable_key="pk_test_...",
    clerk_sign_in_url="https://your-app.clerk.accounts.dev/sign-in",
    session_secret="a-long-random-string",   # v0.7 — signs __dca_identity cookie
    backend="auto",        # v0.6 — flask | fastapi | quart, autodetected
    enable_billing=True,   # optional — unlocks @require_plan / @require_feature
    headless=True,         # skip the fixed-position avatar; we embed ours below
)

# Flask: app = Dash(__name__, external_stylesheets=[dmc.styles.ALL])
# FastAPI (Dash 4.2+, WebSocket callbacks):
app = Dash(
    __name__,
    backend="fastapi",
    websocket_callbacks=True,
    external_stylesheets=[dmc.styles.ALL],
)
configure_app(app)
# Optional, FastAPI/Quart on Dash 4.2+: opt-in WebSocket auth
# from dash_clerk_auth import register_websocket_auth
# register_websocket_auth(on_anonymous="allow")

app.layout = dmc.MantineProvider(
    dmc.AppShell(
        [
            dmc.AppShellHeader(
                dmc.Group(
                    [dmc.Title("My app", order=4), create_clerk_menu()],
                    justify="space-between", h="100%", px="md",
                )
            ),
            dmc.AppShellMain(dmc.Text("Hello, Clerk!")),
        ],
        header={"height": 60},
    )
)

if __name__ == "__main__":
    app.run(debug=True)
"""

EXAMPLES = [
    {
        "title": "Quickstart",
        "desc": "End-to-end: install, env vars, register, run.",
        "icon": "tabler:rocket",
        "color": "blue",
        "href": "/quickstart",
    },
    {
        "title": "register_clerk_auth props",
        "desc": "Every kwarg with its default, type, and effect.",
        "icon": "tabler:settings-cog",
        "color": "indigo",
        "href": "/register-props",
    },
    {
        "title": "clerk-auth-store",
        "desc": "Inspect the live auth payload the hook broadcasts.",
        "icon": "tabler:database",
        "color": "cyan",
        "href": "/auth-store",
    },
    {
        "title": "@require_auth",
        "desc": "Gate a callback behind an authenticated session.",
        "icon": "tabler:lock",
        "color": "teal",
        "href": "/require-auth",
    },
    {
        "title": "@require_plan",
        "desc": "Gate callbacks on Clerk Billing plan membership.",
        "icon": "tabler:diamond",
        "color": "grape",
        "href": "/require-plan",
    },
    {
        "title": "@require_feature",
        "desc": "Gate callbacks on a Clerk feature flag.",
        "icon": "tabler:key",
        "color": "violet",
        "href": "/require-feature",
    },
    {
        "title": "User info helpers",
        "desc": "get_current_user_id, get_user_info, has_plan, has_feature.",
        "icon": "tabler:user-circle",
        "color": "orange",
        "href": "/user-info",
    },
    {
        "title": "Debug panel",
        "desc": "Live auth inspector, toggled via show_debug_panel.",
        "icon": "tabler:bug",
        "color": "red",
        "href": "/debug-panel",
    },
    {
        "title": "Billing",
        "desc": "enable_billing + Clerk PricingTable integration.",
        "icon": "tabler:credit-card",
        "color": "green",
        "href": "/billing",
    },
    {
        "title": "Multi-domain (galaxy)",
        "desc": "Primary + satellites pattern for subdomain constellations.",
        "icon": "tabler:satellite",
        "color": "cyan",
        "href": "/multi-domain",
    },
]


def _example_card(example):
    return dcc.Link(
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            dmc.ThemeIcon(
                                DashIconify(icon=example["icon"], width=22),
                                variant="light",
                                color=example["color"],
                                size="xl",
                                radius="md",
                            ),
                            dmc.Text(example["title"], fw=600, size="md"),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(example["desc"], size="sm", c="dimmed"),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
            style={"height": "100%", "cursor": "pointer", "transition": "transform .15s"},
            className="home-card",
        ),
        href=example["href"],
        style={"textDecoration": "none", "color": "inherit"},
    )


layout = dmc.Stack(
    [
        # Hero
        dmc.Stack(
            [
                dmc.Badge(
                    "v0.7.0 · Dash 3 / 4 / 4.2 WebSocket · Flask + FastAPI",
                    size="lg",
                    variant="dot",
                    color="blue",
                ),
                dmc.Title("Clerk authentication for Dash", order=1),
                dmc.Text(
                    "A Dash plugin that wires Clerk's drop-in auth UI into your app "
                    "with one function call. Protected callbacks, billing-gated "
                    "content, session helpers, and a liquid-glass UI — zero "
                    "boilerplate.",
                    size="lg",
                    c="dimmed",
                    maw=720,
                ),
                dmc.Group(
                    [
                        dmc.Anchor(
                            dmc.Button(
                                "Get started",
                                leftSection=DashIconify(icon="tabler:rocket", width=16),
                                size="md",
                            ),
                            href="/quickstart",
                        ),
                        dmc.Anchor(
                            dmc.Button(
                                "GitHub",
                                leftSection=DashIconify(icon="mdi:github", width=16),
                                size="md",
                                variant="default",
                            ),
                            href="https://github.com/pip-install-python/dash-clerk-auth",
                            target="_blank",
                        ),
                    ],
                    gap="sm",
                ),
            ],
            gap="md",
            py="xl",
        ),
        dmc.Divider(),
        # Install + quickstart code
        dmc.Grid(
            [
                dmc.GridCol(
                    dmc.Paper(
                        dmc.Stack(
                            [
                                dmc.Title("Install", order=4),
                                dmc.CodeHighlight(code=INSTALL, language="bash"),
                            ],
                            gap="sm",
                        ),
                        p="lg",
                        radius="md",
                        withBorder=True,
                    ),
                    span={"base": 12, "md": 4},
                ),
                dmc.GridCol(
                    dmc.Paper(
                        dmc.Stack(
                            [
                                dmc.Title("Quickstart", order=4),
                                dmc.CodeHighlight(code=QUICKSTART, language="python"),
                            ],
                            gap="sm",
                        ),
                        p="lg",
                        radius="md",
                        withBorder=True,
                    ),
                    span={"base": 12, "md": 8},
                ),
            ],
            gutter="md",
        ),
        # Examples grid
        dmc.Title("Limited working examples", order=2, mt="xl"),
        dmc.Text(
            "Each page is a single-concept demo. Open the source in the repo at "
            "examples/pages/<page>.py to see the full snippet.",
            size="sm",
            c="dimmed",
        ),
        dmc.SimpleGrid(
            [_example_card(e) for e in EXAMPLES],
            cols={"base": 1, "sm": 2, "lg": 3},
            spacing="md",
        ),
    ],
    gap="lg",
)