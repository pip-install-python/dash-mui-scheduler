"""
@require_auth — gate a callback on an authenticated session.

Callback-style pattern for clientside gating: read clerk-auth-store, branch
on user_id. The @require_auth decorator is the server-side analogue — use it
for callbacks that hit Flask routes directly.
"""

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, html, no_update
from dash_iconify import DashIconify

dash.register_page(__name__, path="/require-auth", name="@require_auth", order=4)

CALLBACK_GATE = '''from dash import callback, Input, Output

@callback(
    Output("protected-content", "children"),
    Input("load-btn", "n_clicks"),
    State("clerk-auth-store", "data"),
    prevent_initial_call=True,
)
def load_protected(n, auth):
    if not auth or not auth.get("user_id"):
        return dmc.Alert("Sign in to continue", color="yellow")
    return dmc.Text(f"Secret data for {auth['email']}")
'''

DECORATOR = '''from dash_clerk_auth import require_auth

@app.server.route("/api/my-data")
@require_auth
def my_data():
    # Only runs when a Flask session is present and valid.
    return jsonify(ok=True)
'''


layout = dmc.Stack(
    [
        dmc.Title("@require_auth", order=1),
        dmc.Text(
            "Two ways to gate access: a callback pattern (for Dash callbacks) and a "
            "decorator (for Flask routes). Both check the same underlying session.",
            c="dimmed",
        ),
        # Live demo
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:lock", width=20),
                            dmc.Text("Live demo", fw=600),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(
                        "Click the button. If you're signed in, you'll see the protected "
                        "payload. If not, you'll see a prompt to sign in.",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.Button(
                        "Load protected data",
                        id="require-auth-btn",
                        leftSection=DashIconify(icon="tabler:lock-open", width=16),
                    ),
                    html.Div(id="require-auth-output"),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Callback pattern
        dmc.Title("Callback pattern (recommended for Dash)", order=3, mt="md"),
        dmc.Text(
            "For UI state, read clerk-auth-store in the callback and branch. This "
            "keeps the happy path fast — no Flask context switch — and lets you "
            "render a nice 'please sign in' UI instead of a redirect.",
            size="sm",
        ),
        dmc.CodeHighlight(code=CALLBACK_GATE, language="python"),
        # Decorator pattern
        dmc.Title("@require_auth decorator (for Flask routes)", order=3, mt="md"),
        dmc.Text(
            "Use this on routes you add to app.server — file downloads, API "
            "endpoints, webhooks you want restricted. On a missing session it "
            "redirects to clerk_sign_in_url.",
            size="sm",
        ),
        dmc.CodeHighlight(code=DECORATOR, language="python"),
        dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text(
                        "@require_auth (Flask-only, route-level) gracefully degrades to None "
                        "outside a request context — added in 0.5.0.",
                        size="sm",
                    ),
                    dmc.Text(
                        "v0.6+: prefer @require_auth_layout / @require_role_layout / "
                        "@require_plan_layout / @require_feature_layout for Dash layouts. "
                        "They're backend-neutral (Flask + FastAPI/Quart) and read identity "
                        "via current_user(), which v0.7 made reliable in Dash 4.2 "
                        "WebSocket-served callbacks via the per-renderer registry.",
                        size="sm",
                    ),
                ],
                gap="xs",
            ),
            title="Layout-level alternatives (v0.6+, recommended)",
            color="blue",
            icon=DashIconify(icon="tabler:info-circle"),
        ),
    ],
    gap="md",
)


@callback(
    Output("require-auth-output", "children"),
    Input("require-auth-btn", "n_clicks"),
    State("clerk-auth-store", "data"),
    prevent_initial_call=True,
)
def _load_protected(n, auth):
    if not auth or not auth.get("user_id"):
        return dmc.Alert(
            "You're not signed in. Open the avatar menu in the top-right corner.",
            color="yellow",
            icon=DashIconify(icon="tabler:alert-triangle"),
            mt="sm",
        )
    return dmc.Alert(
        dmc.Stack(
            [
                dmc.Text(f"Welcome, {auth.get('first_name') or auth.get('email', 'user')}!", fw=600),
                dmc.Text(f"User ID: {auth['user_id']}", size="xs", ff="monospace", c="dimmed"),
                dmc.Text("This message only renders when clerk-auth-store has a user_id.", size="sm"),
            ],
            gap=4,
        ),
        color="green",
        icon=DashIconify(icon="tabler:check"),
        mt="sm",
    )