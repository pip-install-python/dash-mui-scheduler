"""
Billing — Clerk's pricing + subscription layer.

Walk-through of enable_billing=True: what gets added to the clerk-auth-store,
how to gate UI on plan / features, and how to drop in the Clerk PricingTable
so your users can upgrade without leaving your app.
"""

import dash
import dash_mantine_components as dmc
from dash import Input, Output, callback, html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/billing", name="Clerk billing", order=9)

REGISTER_CODE = """register_clerk_auth(
    clerk_secret_key=...,
    clerk_publishable_key=...,
    clerk_sign_in_url=...,
    enable_billing=True,   # <-- flip this on
)
"""

JWT_TEMPLATE = """# In the Clerk dashboard → Sessions → JWT templates, add these claims:
{
    "plan":     "{{user.public_metadata.plan}}",
    "features": "{{user.public_metadata.features}}"
}
# The hook parses both on every session update and writes them to
# clerk-auth-store.plan / clerk-auth-store.features for you.
"""

PRICING_TABLE = """# Drop Clerk's PricingTable anywhere in your layout:
html.Div(
    '<clerk-pricing-table></clerk-pricing-table>',
    dangerously_allow_html=True,
)

# clerk.browser.js (injected by the hook) hydrates the custom element
# using the appearance you configured in the Clerk dashboard.
"""

UPGRADE_PATTERN = """@callback(
    Output('upgrade-card', 'style'),
    Input('clerk-auth-store', 'data'),
)
def show_upgrade(auth):
    plan = ((auth or {}).get('plan') or 'free').lower()
    # Hide the card once the user is on a paid plan
    return {'display': 'none'} if plan != 'free' else {}
"""

BILLING_FLOW = [
    {
        "step": "1",
        "title": "Enable Clerk Billing",
        "icon": "tabler:credit-card",
        "body": "In the Clerk dashboard, open Billing and turn on paid plans. Connect your Stripe account.",
    },
    {
        "step": "2",
        "title": "Define plans & features",
        "icon": "tabler:list",
        "body": "Create 'free', 'pro', and 'enterprise' (or your own names). Attach features to each plan.",
    },
    {
        "step": "3",
        "title": "Add JWT claims",
        "icon": "tabler:key",
        "body": "In Sessions → JWT templates, expose public_metadata.plan and public_metadata.features as session claims.",
    },
    {
        "step": "4",
        "title": "enable_billing=True",
        "icon": "tabler:power",
        "body": "Pass enable_billing=True to register_clerk_auth. The hook starts parsing the plan + features claims.",
    },
    {
        "step": "5",
        "title": "Gate your callbacks",
        "icon": "tabler:lock",
        "body": "Use @require_plan / @require_feature decorators, or read clerk-auth-store.plan in a callback.",
    },
    {
        "step": "6",
        "title": "Embed the PricingTable",
        "icon": "tabler:table",
        "body": "Drop <clerk-pricing-table /> into your layout — users can upgrade without leaving the app.",
    },
]


def _flow_card(step):
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.Badge(step["step"], size="lg", variant="filled", color="blue", radius="sm"),
                        dmc.ThemeIcon(
                            DashIconify(icon=step["icon"], width=20),
                            variant="light",
                            color="blue",
                            size="lg",
                            radius="md",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.Text(step["title"], fw=600),
                dmc.Text(step["body"], size="sm", c="dimmed"),
            ],
            gap="xs",
        ),
        p="md",
        radius="md",
        withBorder=True,
        style={"height": "100%"},
    )


layout = dmc.Stack(
    [
        dmc.Title("Clerk Billing", order=1),
        dmc.Text(
            "dash-clerk-auth mirrors Clerk's Billing + Stripe integration into your "
            "Dash app. Flip enable_billing=True on register_clerk_auth() and the hook "
            "starts piping plan + feature claims into clerk-auth-store for you.",
            c="dimmed",
        ),
        # Current state preview
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:receipt", width=20),
                            dmc.Text("Your current subscription", fw=600),
                        ],
                        gap="sm",
                    ),
                    html.Div(id="billing-status"),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Integration flow
        dmc.Title("Integration flow", order=2, mt="md"),
        dmc.SimpleGrid(
            [_flow_card(s) for s in BILLING_FLOW],
            cols={"base": 1, "sm": 2, "lg": 3},
            spacing="md",
        ),
        # Register code
        dmc.Title("1. register_clerk_auth", order=3, mt="md"),
        dmc.CodeHighlight(code=REGISTER_CODE, language="python"),
        # JWT
        dmc.Title("2. JWT template (in the Clerk dashboard)", order=3, mt="md"),
        dmc.CodeHighlight(code=JWT_TEMPLATE, language="json"),
        # Pricing table
        dmc.Title("3. Embed the PricingTable", order=3, mt="md"),
        dmc.CodeHighlight(code=PRICING_TABLE, language="python"),
        # Upgrade pattern
        dmc.Title("4. Show an upgrade CTA to free users", order=3, mt="md"),
        dmc.CodeHighlight(code=UPGRADE_PATTERN, language="python"),
        dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text("Want a production-ready template?", fw=600),
                    dmc.Text(
                        "The full multi-page billing template (9 pages, ~5,300 LOC, "
                        "dynamic pricing, webhook handlers) is sold separately at "
                        "shop.geomapindex.com/catalogue/dash-clerk-auth-stripe-billing.",
                        size="sm",
                    ),
                ],
                gap="xs",
            ),
            title="Production template",
            color="blue",
            icon=DashIconify(icon="tabler:external-link"),
        ),
    ],
    gap="md",
)


@callback(
    Output("billing-status", "children"),
    Input("clerk-auth-store", "data"),
)
def _render_status(auth):
    auth = auth or {}
    if not auth.get("user_id"):
        return dmc.Text(
            "Sign in to see your plan and feature entitlements.",
            size="sm",
            c="dimmed",
        )

    plan = (auth.get("plan") or "free").lower()
    features = auth.get("features") or []
    plan_color = {"free": "gray", "pro": "blue", "enterprise": "grape"}.get(plan, "blue")

    return dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Text("Plan:", size="sm", c="dimmed"),
                    dmc.Badge(
                        plan.upper(),
                        color=plan_color,
                        variant="filled",
                        size="md",
                    ),
                ],
                gap="sm",
            ),
            dmc.Group(
                [
                    dmc.Text("Features:", size="sm", c="dimmed"),
                    *(
                        [dmc.Badge(f, variant="light", color="cyan", size="sm") for f in features]
                        if features
                        else [dmc.Text("none", size="sm", fs="italic", c="dimmed")]
                    ),
                ],
                gap="sm",
            ),
        ],
        gap="xs",
    )