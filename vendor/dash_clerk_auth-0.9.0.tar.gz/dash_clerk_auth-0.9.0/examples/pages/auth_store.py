"""
clerk-auth-store — inspect the live auth payload.

The hook injects a hidden dcc.Store(id="clerk-auth-store") into the layout and
keeps it synchronised with Clerk.user / Clerk.session via set_props. Any
callback can subscribe to it by adding Input("clerk-auth-store", "data").
"""

import json

import dash
import dash_mantine_components as dmc
from dash import Input, Output, callback, html
from dash_iconify import DashIconify

dash.register_page(__name__, path="/auth-store", name="clerk-auth-store", order=3)

SUBSCRIBE_EXAMPLE = '''from dash import callback, Input, Output

@callback(
    Output("my-greeting", "children"),
    Input("clerk-auth-store", "data"),
)
def greet(auth):
    if not auth or not auth.get("user_id"):
        return "Please sign in."
    return f"Hello, {auth.get('first_name') or auth['email']}!"
'''

PAYLOAD_SHAPE = """{
    "user_id":    "user_2abc...",
    "email":      "user@example.com",
    "first_name": "John",
    "last_name":  "Doe",
    "image_url":  "https://img.clerk.com/...",
    "session_id": "sess_2xyz...",

    # only present when register_clerk_auth(enable_billing=True)
    "plan":     "pro",
    "features": ["charts_export", "advanced_alerts"],
}"""

layout = dmc.Stack(
    [
        dmc.Title("clerk-auth-store", order=1),
        dmc.Text(
            "A dcc.Store injected by the hook. It's updated on every Clerk "
            "session change (sign-in, sign-out, user-switch) via set_props, "
            "so callbacks that depend on it re-fire automatically.",
            c="dimmed",
        ),
        # Live view
        dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="tabler:radar", width=20),
                            dmc.Text("Live payload", fw=600),
                            dmc.Badge("updates on sign-in / sign-out", color="blue", variant="light", size="xs"),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(
                        "Sign in with the avatar in the top-right to see this populate. "
                        "If you're running in docs-only mode (no Clerk keys), you'll get "
                        "a 'not signed in' object.",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.CodeHighlight(
                        id="auth-store-live",
                        code="Waiting for clerk-auth-store to update...",
                        language="json",
                    ),
                ],
                gap="sm",
            ),
            p="lg",
            radius="md",
            withBorder=True,
        ),
        # Shape reference
        dmc.Title("Payload shape", order=3, mt="md"),
        dmc.CodeHighlight(code=PAYLOAD_SHAPE, language="json"),
        # Usage example
        dmc.Title("Reading it from a callback", order=3, mt="md"),
        dmc.CodeHighlight(code=SUBSCRIBE_EXAMPLE, language="python"),
        dmc.Alert(
            dmc.Text(
                "clerk-auth-store is storage_type='memory' by design — it's rebuilt "
                "from the browser-side Clerk session on every page load so "
                "page refreshes always get a fresh view.",
                size="sm",
            ),
            title="Why memory?",
            color="gray",
            icon=DashIconify(icon="tabler:help-circle"),
        ),
    ],
    gap="md",
)


@callback(
    Output("auth-store-live", "code"),
    Input("clerk-auth-store", "data"),
)
def _render_live(auth):
    if not auth:
        return '{\n    "status": "not signed in — open the avatar menu to sign in"\n}'
    return json.dumps(auth, indent=4, default=str)