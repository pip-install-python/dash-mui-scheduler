# dash-clerk-auth

<div align="center">
  <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Plotly-logo.png" height="60" />
   
  
</div>
<div align="center">
    <img src="https://images.clerk.com/static/logo-light-mode-400x400.png" height="60" />

<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Stripe_Logo%2C_revised_2016.svg/1280px-Stripe_Logo%2C_revised_2016.svg.png" height="60" />

  <h3>Seamless Clerk Authentication for Dash Applications</h3>
  
  [![PyPI version](https://badge.fury.io/py/dash-clerk-auth.svg)](https://badge.fury.io/py/dash-clerk-auth)
  [![Python](https://img.shields.io/pypi/pyversions/dash-clerk-auth.svg)](https://pypi.org/project/dash-clerk-auth/)
  [![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
</div>

## Overview

`dash-clerk-auth` is a Dash plugin that wires [Clerk](https://clerk.com)
authentication into a Dash app with one function call. It works on
**Dash 3.x (Flask)** and **Dash 4.x (Flask, FastAPI, or Quart)**, including
Dash 4.2's WebSocket-served callbacks.

### What's new in 0.9

- 📧 **`user.email` is populated everywhere** — Clerk session JWTs carry no
  email claim by default; verified identities are now enriched via the users
  API (once per user per process, cached) before any caching or cookie mint.
- 🌶️ **Flask gets real server-side identity** — `before_request` now runs the
  same slow-path Clerk verify + `__dca_identity` mint as the ASGI middleware,
  so `current_user()` works on `backend="flask"` with zero client cooperation.
- 🔌 **WS auth registers itself** — `configure_app` on an ASGI backend wires
  the Dash 4.2 WebSocket hooks automatically (`websocket_auth=False` to opt
  out, `ws_auth_registered()` to assert).
- 🤫 **Quieter idle logs** — requests carrying only `__client_uat`/`__refresh_*`
  (Clerk's ~60s JWT rotation gap) skip the guaranteed-reject verify and log at
  DEBUG instead of INFO.

### Core features (0.7+)

- 🔐 **One-call setup** — `register_clerk_auth(...) → configure_app(app)` and the
  liquid-glass sign-in UI, the `clerk-auth-store` Store, and the auth routes
  all wire themselves up.
- 🚀 **FastAPI / Quart support (Dash 4)** — `backend="auto"` autodetects ASGI
  and installs `ClerkASGIMiddleware` on HTTP **and** WebSocket scope.
- 🍪 **Signed `__dca_identity` cookie** — verified-positive cache for the Clerk
  verdict. The first request after sign-in pays the JWKS roundtrip and mints
  the cookie; every subsequent request verifies it locally in microseconds.
- 🛰️ **Dash 4.2 WebSocket auth that actually works** — `register_websocket_auth()`
  defaults to `on_anonymous="allow"` (mixed-traffic safe) and bridges Dash's
  thread-pool callback dispatch via a per-renderer identity registry, so
  `current_user()` is reliable inside WS-served callbacks.
- 🛡️ **Server-side layout decorators** — `@require_auth_layout`,
  `@require_role_layout`, `@require_plan_layout`, `@require_feature_layout`
  fail-closed by default and commit to one branch *before* a heavy admin
  layout builds.
- 👤 **Backend-neutral `current_user()`** — same call site works on Flask and
  FastAPI, on HTTP and WS, on sync and async callbacks.
- 💰 **Clerk Billing support** — `enable_billing=True` populates `plan` and
  `features` so `@require_plan_layout` / `@require_feature_layout` can gate
  on Clerk's monthly-payment system.
- 🧰 **Async Clerk SDK wrappers** — `await averify_request(...)`,
  `await aget_user_by_id(...)`, `await alist_users_cached(...)` with TTL
  caches and single-flight de-dup, for `async def` callbacks on FastAPI.

## Installation

```bash
# Flask backend (Dash 3 or 4 WSGI):
pip install dash-clerk-auth

# Dash 4 ASGI (FastAPI / Quart) — required for WebSocket auth:
pip install 'dash-clerk-auth[fastapi]' 'dash[fastapi]>=4.2.0rc1'
```

### Requirements

- Python 3.9+
- Dash 3.0.3+ — first-class Dash 4.0 / 4.1 / 4.2.0rc3 support
- `clerk-backend-api>=5.0.0,<6`
- A Clerk account with API keys

## Quick start (Flask, Dash 3.x or 4.x WSGI)

```python
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],   # signs the identity cookie
)

app = Dash(__name__, external_stylesheets=[dmc.styles.ALL])
configure_app(app)

app.layout = dmc.MantineProvider(dmc.Container("Hello, Clerk!", py="xl"))

if __name__ == "__main__":
    app.run(debug=True)
```

## Quick start (FastAPI / Dash 4.2 with WebSocket callbacks)

```python
import os
from dash import Dash
import dash_mantine_components as dmc
from dash_clerk_auth import register_clerk_auth, configure_app

register_clerk_auth(
    clerk_secret_key=os.environ["CLERK_SECRET_KEY"],
    clerk_publishable_key=os.environ["CLERK_PUBLISHABLE_KEY"],
    clerk_sign_in_url=os.environ["CLERK_SIGN_IN_URL"],
    session_secret=os.environ["SESSION_SECRET"],
    backend="auto",            # detects FastAPI from app.server
)

app = Dash(
    __name__,
    backend="fastapi",
    external_stylesheets=[dmc.styles.ALL],
)
configure_app(app)   # v0.9: WebSocket auth hooks are registered automatically

# Run with: uvicorn examples.app_fastapi:server --port 8050 --reload
```

`app.server` is now a FastAPI instance with the Clerk middleware on HTTP +
WebSocket scope, the signed-cookie session middleware, the
`/api/auth/{session,signout}` routes mounted, and (since v0.9) the Dash 4.2
WebSocket auth hooks registered. To customise the WS behaviour (e.g.
`on_anonymous="close"`), call `register_websocket_auth(...)` yourself
**before** `configure_app` — it's idempotent and the first registration wins.
Opt out entirely with `register_clerk_auth(..., websocket_auth=False)`.

### Choosing the WebSocket transport (Dash 4.2)

Prefer per-callback `@callback(websocket=True)` over the global
`Dash(websocket_callbacks=True)` flag. The renderer's transport rule is
`global_enabled || callback.websocket`, and it opens the socket whenever the
backend advertises the WS urls — so persistent / `set_props` callbacks keep
working with the global flag off, while ordinary callbacks ride HTTP where
cookies and middleware exist:

```python
app = Dash(__name__, backend="fastapi")   # global WS flag OFF

@callback(Output("feed", "children"), Input("tick", "n_intervals"),
          websocket=True)                 # only THIS callback rides the socket
async def stream_feed(_):
    ...
```

With the global flag on, **every** callback — including the pages router —
is delivered over `/_dash-ws-callback` and executes in a thread pool, so
server-side identity depends entirely on the WS auth hooks. They're
registered automatically since v0.9, but the narrower per-callback opt-in
keeps most of your app on the boring, well-understood HTTP path.

## What you get out of the box

- ✅ Clerk's drop-in sign-in / sign-up UI (liquid-glass styled, theme-aware
  light/dark mode).
- ✅ Avatar in the top-right (or embedded via `create_clerk_menu()` when
  `headless=True`).
- ✅ A hidden `dcc.Store(id="clerk-auth-store")` populated server-side at
  layout build time AND client-side on every Clerk session change.
- ✅ Server-side identity available everywhere via `current_user()` —
  ContextVar, WS registry, Flask `g`, or Flask `session`, in that order.
- ✅ Cookie-based identity persistence — `__dca_identity` is signed against
  `session_secret` and rotated on every successful Clerk verify.

## Reading identity in your code

### From a callback (any backend, HTTP or WS)

```python
from dash import Input, Output, callback
from dash_clerk_auth import current_user

@callback(
    Output("greeting", "children"),
    Input("clerk-auth-store", "data"),   # fires on session change
)
def greet(_auth_data):
    user = current_user()                # backend-neutral, transport-neutral
    if user is None:
        return "Sign in to continue."
    return f"Welcome, {user.first_name or user.email}!"
```

### Gating a Dash page server-side

```python
import dash
from dash_clerk_auth import require_role_layout

@require_role_layout("admin")            # fail-closed by default
def layout():
    return _build_heavy_admin_dashboard()  # NEVER builds for anonymous visitors

dash.register_page(__name__, path="/admin", layout=layout)
```

The `@require_*_layout` family commits to one branch — protected layout OR
forbidden placeholder — *before* any callback fires. The heavy admin layout
never builds for an anonymous visitor, so you don't pay its render cost on
every bot crawl.

### Gating on Clerk Billing plan / feature flag

```python
from dash_clerk_auth import require_plan_layout, require_feature_layout

@require_plan_layout(["pro", "enterprise"])
def layout():
    return _build_pro_dashboard()

@require_feature_layout("advanced_export")
def layout():
    return _build_export_panel()
```

Pair with `register_clerk_auth(..., enable_billing=True)` so the JWT's plan
and features claims get projected onto `ClerkUser`.

### Async Clerk reads (FastAPI only)

```python
from dash import Output, Input, callback
from dash_clerk_auth import alist_users_cached

@callback(
    Output("user-table", "children"),
    Input("refresh-btn", "n_clicks"),
    prevent_initial_call=False,
)
async def render_users(n_clicks):
    force = bool(n_clicks and n_clicks > 0)
    users = await alist_users_cached(force=force)   # 60s TTL, single-flight
    return _table(users)
```

## Configuration reference

```python
register_clerk_auth(
    # --- required ---
    clerk_secret_key="sk_test_...",         # from Clerk dashboard
    clerk_publishable_key="pk_test_...",
    clerk_sign_in_url="https://your-app.clerk.accounts.dev/sign-in",

    # --- session + identity cookie (v0.7) ---
    session_secret="long-random-string",    # signs Flask/Starlette session AND __dca_identity
    session_lifetime_days=7,                # cookie Max-Age

    # --- backend (v0.6) ---
    backend="auto",                          # "auto" | "flask" | "fastapi" | "quart"
    on_unverified="forbidden",               # layout-decorator default: forbidden | allow | passthrough
    verify_timeout=5.0,
    authorized_parties=None,                 # optional Clerk azp whitelist
    websocket_auth=True,                     # v0.9 — auto-register Dash 4.2 WS auth hooks (ASGI)

    # --- billing (Clerk's monthly-payment system) ---
    enable_billing=False,                    # populates ClerkUser.plan + .features

    # --- ergonomics ---
    debug=False,
    show_debug_panel=None,
    headless=False,                          # skip the fixed-position avatar UI
    enable_proxy_fix=True,                   # Flask only

    # --- multi-domain (satellite galaxy) ---
    is_satellite=False,
    satellite_domain=None,
    sign_up_url=None,
    clerk_frontend_api=None,
    allowed_redirect_origins=None,
)

# Registered automatically by configure_app since v0.9 (ASGI backends).
# Call it yourself BEFORE configure_app only to customise — first one wins:
register_websocket_auth(
    on_anonymous="allow",                    # "allow" (default) | "close" (v0.6 fail-closed)
    close_code=4401,
    close_reason="unauthenticated",
)
```

> **`SESSION_SECRET` must be a fixed value** — identical across replicas
> and across deploys. It signs the `__dca_identity` cookie; a per-deploy
> generated secret invalidates every signed identity on each release. The
> symptom is "slow-path Clerk verify rejected" / repeated slow-path verifies
> right after deploying, until each user's identity is re-minted.

## How the cookie path works (the v0.7 reliability story)

Every authenticated request goes through one of two paths:

1. **Fast path** — `__dca_identity` cookie present and valid (HMAC verify,
   microseconds, no I/O). 99% of requests hit this.
2. **Slow path** — no cookie or cookie expired → call Clerk's
   `authenticate_request_async` (JWKS roundtrip), and on success mint a fresh
   `__dca_identity` cookie on the response. Hits this on the very first
   request after sign-in, then once per `session_lifetime_days`.

The cookie is:

- **Signed** with `itsdangerous.URLSafeTimedSerializer(session_secret)`.
- **HttpOnly + SameSite=Lax**, with `Secure` set automatically when behind a
  TLS-terminating proxy (`X-Forwarded-Proto: https`).
- **Bounded by `session_lifetime_days`**, NOT by the JWT's `exp` — Clerk dev
  JWTs rotate every 60 seconds; the cookie's job is to cache the *identity*
  across many JWT refreshes.

For Dash 4.2 WebSocket-served callbacks, the package additionally:

- Runs the ASGI middleware on `scope["type"] == "websocket"` so the WS
  upgrade resolves identity the same way HTTP does.
- Bridges Dash's thread-pool callback dispatch via a `renderer_id → ClerkUser`
  registry (see `dash_clerk_auth/_ws_registry.py`) — `concurrent.futures`
  doesn't propagate ContextVars, so the registry is what makes
  `current_user()` work inside the worker thread.

Full architectural write-up:
[`.claude/planning/0.7-architecture-and-bug-postmortem.md`](.claude/planning/0.7-architecture-and-bug-postmortem.md).

## Multi-page apps

`dash-clerk-auth` works seamlessly with Dash Pages — register a page, add a
layout decorator if needed, that's it:

```python
# pages/admin.py
import dash
from dash_clerk_auth import require_role_layout

@require_role_layout("admin")
def layout(**_kwargs):
    return _build_admin_dashboard()

dash.register_page(__name__, path="/admin", layout=layout)
```

> **Always accept `**kwargs` in callable page layouts.** Dash Pages forwards
> query-string parameters to callable layouts as keyword arguments, and
> Clerk's sign-in flow redirects back with `?__clerk_handshake=...` — a bare
> `def layout():` raises `TypeError` (a 500) on exactly that redirect.

## Authentication store

`@hooks.layout()` injects a hidden `dcc.Store(id="clerk-auth-store")` and
**pre-populates its `data`** from `current_user()` at layout build time
(v0.7). Client-side, Clerk JS keeps it in sync with `set_props` on every
session change.

```python
{
    "user_id": "user_2abc123...",
    "session_id": "sess_2def456...",
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "image_url": "https://img.clerk.com/...",
    "role": "admin",                    # when present in JWT public_metadata
    "plan": "pro",                      # when enable_billing=True
    "features": ["advanced_export"],    # when enable_billing=True
}
```

## UI components

The plugin automatically injects:

1. **Authentication menu** — fixed-position avatar in the top-right (or
   embed wherever you want via `create_clerk_menu()` with
   `headless=True`).
2. **Debug panel** (when `show_debug_panel=True`) — bottom-right inspector
   showing live auth state.

## Stripe / Clerk Billing

Interested in monetizing your apps? `dash-clerk-auth` supports Clerk's
membership feature, with `@require_plan_layout` and `@require_feature_layout`
to gate pages and callbacks on the user's subscription.

<div align="center">
  <a href="https://youtu.be/SOQhRhQQqbA">
    <img src="assets/clerk_stripe_dash_thumbnail.jpg" alt="Video Title">
    <br>
    <img src="https://img.shields.io/badge/-Watch%20Demo-red?style=for-the-badge&logo=youtube" alt="Watch Demo">
  </a>
</div>

If you want a fully-fledged template with multiple pages, dynamic pricing,
and the full membership flow, check out the example code in my e-commerce
shop:

[shop.geomapindex.com — dash-clerk-auth + Stripe Billing](https://shop.geomapindex.com/catalogue/dash-clerk-auth-stripe-billing_9/)

- ✍️ 9 pages, ~5,300 lines of code
- 🚀 Showcases all aspects of multi-page authentication
- 🤑 Integrated membership and dynamic pricing table
- 📖 Step-by-step setup instructions

## Examples

The repo's `examples/` folder ships:

- `examples/app.py` — Flask backend (Dash 3 / 4 WSGI)
- `examples/app_fastapi.py` — FastAPI backend with WebSocket callbacks
- `examples/pages/` — limited working examples for each major feature
  (quickstart, register-props, auth-store, require-auth, require-plan,
  require-feature, user-info, debug-panel, billing, multi-domain)

## Troubleshooting

**`current_user()` returns `None` inside a Dash 4.2 WS callback**
- Make sure you're on `dash-clerk-auth >= 0.7.0` — earlier versions
  didn't bridge the WS handshake to the per-callback dispatch.
- Since v0.9 the WS auth hooks are registered automatically by
  `configure_app` on ASGI backends; assert it with
  `dash_clerk_auth.ws_auth_registered()` (e.g. from a health endpoint).
  On `< 0.9`, call `register_websocket_auth()` explicitly.

**`user.email` is `None` for a signed-in user** *(fixed in v0.9)*
- Clerk session JWTs carry **no email claim** by default — only
  `sub`/`sid`/`exp` etc. Since v0.9 the package enriches verified identities
  via Clerk's users API (once per user per process, cached) before caching
  or minting `__dca_identity`, so `user.email` is populated everywhere.
- Alternative that skips the API call entirely: customise your instance's
  session token in the Clerk dashboard to include
  `{"email": "{{user.primary_email_address}}"}`. The package works either
  way; the dashboard route just saves the one-time lookup.

**`__dca_identity` cookie isn't being set**
- Check the terminal for `clerk-auth /...: slow-path Clerk verify rejected ...`
  — the package logs the reject reason, including the JWT's `kid` on
  KID_MISMATCH. (Requests carrying only `__client_uat`/`__refresh_*` — no
  session token — are an expected idle state and log at DEBUG since v0.9.)
- Most common cause: signed into multiple Clerk dev apps on `localhost`. The
  package strips per-app suffixed cookies before handing to Clerk's SDK
  (v0.7), so this should self-heal — clear cookies and re-sign-in if you're
  still seeing it.
- Less common: `CLERK_SECRET_KEY` is from a different Clerk app than
  `CLERK_PUBLISHABLE_KEY`. Confirm both keys belong to the same app in
  the Clerk dashboard.

**Page locks me out then a refresh fixes it**
- This is the v0.6-era WS-bypass-middleware bug; v0.7 resolves it with the
  WS-aware ASGI middleware + the per-renderer registry. Upgrade.

**"User stays logged in after logout"**
- `/api/auth/signout` clears `__dca_identity` and the session. If you see
  stale state, check that Clerk JS is calling the route — the package's
  built-in dropdown handles this; custom UIs need to POST `/api/auth/signout`
  themselves.

**`RuntimeError: dictionary changed size during iteration` on WS disconnect**
- Known **Dash 4.2.0 upstream bug**, not a dash-clerk-auth issue: the
  disconnect cleanup in `dash/backends/_fastapi.py::websocket_handler`
  iterates `pending_callbacks.values()` while executor done-callbacks pop
  from the same dict. It's harmless teardown noise on busy sockets; the fix
  in dash is snapshotting with `list(pending_callbacks.values())`.

### Debug mode

```python
register_clerk_auth(..., debug=True, show_debug_panel=True)

# Optional — surface dash_clerk_auth internal logs:
import logging
logging.basicConfig(level=logging.INFO)
logging.getLogger("dash_clerk_auth").setLevel(logging.DEBUG)
```

## Development

```bash
# Run the test suite (136 tests):
pytest tests/ -q

# Build the wheel:
python -m build --sdist --wheel
```

### Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## License

MIT — see [LICENSE](LICENSE).

## Acknowledgments

- [Plotly Dash](https://dash.plotly.com/) for the framework
- [Clerk](https://clerk.com/) for the authentication platform
- [Dash Mantine Components](https://dash-mantine-components.com/) for UI

## Support

- 💬 Discord: [Join our Discord](https://discord.gg/e5s5uHWUHH)
- 🐛 Issues: [GitHub Issues](https://github.com/pip-install-python/dash-clerk-auth/issues)
- 📋 Forum: [Dash Forums](https://community.plotly.com/)

## Check out my applications

- [Geo🗺️Index](https://dash.geomapindex.com/)
- [Blog](https://geomapindex.com/blog/)
- [E-Commerce site](https://shop.geomapindex.com/catalogue/)

Made with ❤️ for the Dash community
